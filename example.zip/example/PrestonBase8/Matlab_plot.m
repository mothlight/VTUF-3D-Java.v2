
clear

%Tbright_yd172_lp20_bhbl070_lat30N_stror00_tim1300.out
%%%%% change these variables
% julian day
yd='040'
% building plan area ratio (lambdap)
lp='31'
% building height to width ratio (H/L)
bhbl='150'
% latitude (degrees)
lat='38S'
% street orientation, clockwise rotation from N-S-E-W alignment (degrees)
stror='00'
% hour of the day (local mean solar time)
tim='1200'
% variable to plot: Tsfc = surface temperature; Tbright ~= brightness temperature;
% Krefl = reflected solar (after multiple reflections); Kabs = absorbed solar (after multiple reflections)
var='Tsfc'
%%%%%
dir='./'
		
vert2=strcat(dir,'lp',lp,'_bhbl',bhbl,'_vertices_toMatlab.out')
face2=strcat(dir,'lp',lp,'_bhbl',bhbl,'_faces_toMatlab.out')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');

vert=load(vert2);
face=load(face2);
toplot=load(toplot2);

colormap(jet)
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label


axis([60.0,79.0,60.0,79.0])

%set(gca,'YDir','reverse');
axis ij

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='0000'
image=strcat(var,'_', '2004-02-09-0000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-0000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='0100'
image=strcat(var,'_', '2004-02-09-0100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-0100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='0200'
image=strcat(var,'_', '2004-02-09-0200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-0200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='0300'
image=strcat(var,'_', '2004-02-09-0300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-0300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='0400'
image=strcat(var,'_', '2004-02-09-0400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-0400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='0500'
image=strcat(var,'_', '2004-02-09-0500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-0500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='0600'
image=strcat(var,'_', '2004-02-09-0600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-0600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='0700'
image=strcat(var,'_', '2004-02-09-0700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-0700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='0800'
image=strcat(var,'_', '2004-02-09-0800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-0800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='0900'
image=strcat(var,'_', '2004-02-09-0900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-0900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='1000'
image=strcat(var,'_', '2004-02-09-1000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-1000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='1100'
image=strcat(var,'_', '2004-02-09-1100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-1100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='1200'
image=strcat(var,'_', '2004-02-09-1200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-1200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='1300'
image=strcat(var,'_', '2004-02-09-1300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-1300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='1400'
image=strcat(var,'_', '2004-02-09-1400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-1400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='1500'
image=strcat(var,'_', '2004-02-09-1500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-1500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='1600'
image=strcat(var,'_', '2004-02-09-1600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-1600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='1700'
image=strcat(var,'_', '2004-02-09-1700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-1700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='1800'
image=strcat(var,'_', '2004-02-09-1800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-1800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='1900'
image=strcat(var,'_', '2004-02-09-1900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-1900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='2000'
image=strcat(var,'_', '2004-02-09-2000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-2000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='2100'
image=strcat(var,'_', '2004-02-09-2100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-2100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='2200'
image=strcat(var,'_', '2004-02-09-2200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-2200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='2300'
image=strcat(var,'_', '2004-02-09-2300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-2300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='2400'
image=strcat(var,'_', '2004-02-10-0000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-10-0000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='2500'
image=strcat(var,'_', '2004-02-10-0100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-10-0100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='2600'
image=strcat(var,'_', '2004-02-10-0200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-10-0200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='2700'
image=strcat(var,'_', '2004-02-10-0300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-10-0300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='2800'
image=strcat(var,'_', '2004-02-10-0400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-10-0400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='2900'
image=strcat(var,'_', '2004-02-10-0500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-10-0500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='3000'
image=strcat(var,'_', '2004-02-10-0600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-10-0600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='3100'
image=strcat(var,'_', '2004-02-10-0700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-10-0700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='3200'
image=strcat(var,'_', '2004-02-10-0800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-10-0800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='3300'
image=strcat(var,'_', '2004-02-10-0900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-10-0900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='3400'
image=strcat(var,'_', '2004-02-10-1000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-10-1000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='3500'
image=strcat(var,'_', '2004-02-10-1100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-10-1100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='3600'
image=strcat(var,'_', '2004-02-10-1200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-10-1200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='3700'
image=strcat(var,'_', '2004-02-10-1300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-10-1300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='3800'
image=strcat(var,'_', '2004-02-10-1400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-10-1400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='3900'
image=strcat(var,'_', '2004-02-10-1500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-10-1500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='4000'
image=strcat(var,'_', '2004-02-10-1600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-10-1600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='4100'
image=strcat(var,'_', '2004-02-10-1700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-10-1700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='4200'
image=strcat(var,'_', '2004-02-10-1800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-10-1800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='4300'
image=strcat(var,'_', '2004-02-10-1900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-10-1900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='4400'
image=strcat(var,'_', '2004-02-10-2000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-10-2000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='4500'
image=strcat(var,'_', '2004-02-10-2100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-10-2100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='4600'
image=strcat(var,'_', '2004-02-10-2200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-10-2200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='4700'
image=strcat(var,'_', '2004-02-10-2300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-10-2300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='4800'
image=strcat(var,'_', '2004-02-11-0000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-11-0000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='4900'
image=strcat(var,'_', '2004-02-11-0100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-11-0100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='5000'
image=strcat(var,'_', '2004-02-11-0200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-11-0200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='5100'
image=strcat(var,'_', '2004-02-11-0300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-11-0300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='5200'
image=strcat(var,'_', '2004-02-11-0400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-11-0400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='5300'
image=strcat(var,'_', '2004-02-11-0500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-11-0500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='5400'
image=strcat(var,'_', '2004-02-11-0600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-11-0600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='5500'
image=strcat(var,'_', '2004-02-11-0700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-11-0700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='5600'
image=strcat(var,'_', '2004-02-11-0800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-11-0800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='5700'
image=strcat(var,'_', '2004-02-11-0900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-11-0900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='5800'
image=strcat(var,'_', '2004-02-11-1000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-11-1000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='5900'
image=strcat(var,'_', '2004-02-11-1100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-11-1100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='6000'
image=strcat(var,'_', '2004-02-11-1200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-11-1200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='6100'
image=strcat(var,'_', '2004-02-11-1300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-11-1300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='6200'
image=strcat(var,'_', '2004-02-11-1400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-11-1400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='6300'
image=strcat(var,'_', '2004-02-11-1500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-11-1500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='6400'
image=strcat(var,'_', '2004-02-11-1600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-11-1600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='6500'
image=strcat(var,'_', '2004-02-11-1700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-11-1700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='6600'
image=strcat(var,'_', '2004-02-11-1800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-11-1800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='6700'
image=strcat(var,'_', '2004-02-11-1900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-11-1900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='6800'
image=strcat(var,'_', '2004-02-11-2000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-11-2000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='6900'
image=strcat(var,'_', '2004-02-11-2100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-11-2100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='7000'
image=strcat(var,'_', '2004-02-11-2200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-11-2200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='7100'
image=strcat(var,'_', '2004-02-11-2300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-11-2300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='7200'
image=strcat(var,'_', '2004-02-12-0000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-12-0000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='7300'
image=strcat(var,'_', '2004-02-12-0100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-12-0100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='7400'
image=strcat(var,'_', '2004-02-12-0200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-12-0200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='7500'
image=strcat(var,'_', '2004-02-12-0300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-12-0300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='7600'
image=strcat(var,'_', '2004-02-12-0400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-12-0400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='7700'
image=strcat(var,'_', '2004-02-12-0500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-12-0500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='7800'
image=strcat(var,'_', '2004-02-12-0600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-12-0600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='7900'
image=strcat(var,'_', '2004-02-12-0700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-12-0700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='8000'
image=strcat(var,'_', '2004-02-12-0800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-12-0800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='8100'
image=strcat(var,'_', '2004-02-12-0900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-12-0900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='8200'
image=strcat(var,'_', '2004-02-12-1000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-12-1000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='8300'
image=strcat(var,'_', '2004-02-12-1100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-12-1100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='8400'
image=strcat(var,'_', '2004-02-12-1200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-12-1200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='8500'
image=strcat(var,'_', '2004-02-12-1300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-12-1300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='8600'
image=strcat(var,'_', '2004-02-12-1400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-12-1400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='8700'
image=strcat(var,'_', '2004-02-12-1500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-12-1500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='8800'
image=strcat(var,'_', '2004-02-12-1600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-12-1600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='8900'
image=strcat(var,'_', '2004-02-12-1700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-12-1700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='9000'
image=strcat(var,'_', '2004-02-12-1800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-12-1800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='9100'
image=strcat(var,'_', '2004-02-12-1900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-12-1900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='9200'
image=strcat(var,'_', '2004-02-12-2000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-12-2000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='9300'
image=strcat(var,'_', '2004-02-12-2100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-12-2100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='9400'
image=strcat(var,'_', '2004-02-12-2200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-12-2200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='9500'
image=strcat(var,'_', '2004-02-12-2300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-12-2300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='9600'
image=strcat(var,'_', '2004-02-13-0000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-13-0000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='9700'
image=strcat(var,'_', '2004-02-13-0100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-13-0100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='9800'
image=strcat(var,'_', '2004-02-13-0200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-13-0200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='9900'
image=strcat(var,'_', '2004-02-13-0300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-13-0300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='10000'
image=strcat(var,'_', '2004-02-13-0400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-13-0400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='10100'
image=strcat(var,'_', '2004-02-13-0500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-13-0500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='10200'
image=strcat(var,'_', '2004-02-13-0600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-13-0600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='10300'
image=strcat(var,'_', '2004-02-13-0700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-13-0700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='10400'
image=strcat(var,'_', '2004-02-13-0800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-13-0800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='10500'
image=strcat(var,'_', '2004-02-13-0900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-13-0900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='10600'
image=strcat(var,'_', '2004-02-13-1000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-13-1000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='10700'
image=strcat(var,'_', '2004-02-13-1100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-13-1100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='10800'
image=strcat(var,'_', '2004-02-13-1200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-13-1200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='10900'
image=strcat(var,'_', '2004-02-13-1300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-13-1300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='11000'
image=strcat(var,'_', '2004-02-13-1400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-13-1400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='11100'
image=strcat(var,'_', '2004-02-13-1500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-13-1500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='11200'
image=strcat(var,'_', '2004-02-13-1600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-13-1600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='11300'
image=strcat(var,'_', '2004-02-13-1700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-13-1700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='11400'
image=strcat(var,'_', '2004-02-13-1800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-13-1800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='11500'
image=strcat(var,'_', '2004-02-13-1900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-13-1900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='11600'
image=strcat(var,'_', '2004-02-13-2000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-13-2000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='11700'
image=strcat(var,'_', '2004-02-13-2100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-13-2100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='11800'
image=strcat(var,'_', '2004-02-13-2200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-13-2200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='11900'
image=strcat(var,'_', '2004-02-13-2300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-13-2300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='12000'
image=strcat(var,'_', '2004-02-14-0000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-14-0000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='12100'
image=strcat(var,'_', '2004-02-14-0100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-14-0100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='12200'
image=strcat(var,'_', '2004-02-14-0200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-14-0200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='12300'
image=strcat(var,'_', '2004-02-14-0300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-14-0300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='12400'
image=strcat(var,'_', '2004-02-14-0400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-14-0400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='12500'
image=strcat(var,'_', '2004-02-14-0500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-14-0500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='12600'
image=strcat(var,'_', '2004-02-14-0600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-14-0600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='12700'
image=strcat(var,'_', '2004-02-14-0700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-14-0700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='12800'
image=strcat(var,'_', '2004-02-14-0800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-14-0800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='12900'
image=strcat(var,'_', '2004-02-14-0900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-14-0900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='13000'
image=strcat(var,'_', '2004-02-14-1000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-14-1000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='13100'
image=strcat(var,'_', '2004-02-14-1100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-14-1100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='13200'
image=strcat(var,'_', '2004-02-14-1200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-14-1200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='13300'
image=strcat(var,'_', '2004-02-14-1300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-14-1300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='13400'
image=strcat(var,'_', '2004-02-14-1400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-14-1400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='13500'
image=strcat(var,'_', '2004-02-14-1500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-14-1500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='13600'
image=strcat(var,'_', '2004-02-14-1600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-14-1600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='13700'
image=strcat(var,'_', '2004-02-14-1700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-14-1700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='13800'
image=strcat(var,'_', '2004-02-14-1800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-14-1800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='13900'
image=strcat(var,'_', '2004-02-14-1900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-14-1900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='14000'
image=strcat(var,'_', '2004-02-14-2000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-14-2000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='14100'
image=strcat(var,'_', '2004-02-14-2100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-14-2100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='14200'
image=strcat(var,'_', '2004-02-14-2200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-14-2200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='14300'
image=strcat(var,'_', '2004-02-14-2300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-14-2300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='14400'
image=strcat(var,'_', '2004-02-15-0000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-15-0000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='14500'
image=strcat(var,'_', '2004-02-15-0100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-15-0100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='14600'
image=strcat(var,'_', '2004-02-15-0200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-15-0200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='14700'
image=strcat(var,'_', '2004-02-15-0300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-15-0300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='14800'
image=strcat(var,'_', '2004-02-15-0400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-15-0400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='14900'
image=strcat(var,'_', '2004-02-15-0500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-15-0500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='15000'
image=strcat(var,'_', '2004-02-15-0600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-15-0600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='15100'
image=strcat(var,'_', '2004-02-15-0700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-15-0700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='15200'
image=strcat(var,'_', '2004-02-15-0800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-15-0800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='15300'
image=strcat(var,'_', '2004-02-15-0900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-15-0900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='15400'
image=strcat(var,'_', '2004-02-15-1000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-15-1000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='15500'
image=strcat(var,'_', '2004-02-15-1100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-15-1100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='15600'
image=strcat(var,'_', '2004-02-15-1200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-15-1200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='15700'
image=strcat(var,'_', '2004-02-15-1300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-15-1300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='15800'
image=strcat(var,'_', '2004-02-15-1400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-15-1400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='15900'
image=strcat(var,'_', '2004-02-15-1500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-15-1500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='16000'
image=strcat(var,'_', '2004-02-15-1600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-15-1600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='16100'
image=strcat(var,'_', '2004-02-15-1700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-15-1700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='16200'
image=strcat(var,'_', '2004-02-15-1800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-15-1800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='16300'
image=strcat(var,'_', '2004-02-15-1900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-15-1900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='16400'
image=strcat(var,'_', '2004-02-15-2000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-15-2000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='16500'
image=strcat(var,'_', '2004-02-15-2100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-15-2100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='16600'
image=strcat(var,'_', '2004-02-15-2200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-15-2200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='16700'
image=strcat(var,'_', '2004-02-15-2300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-15-2300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='16800'
image=strcat(var,'_', '2004-02-16-0000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-16-0000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='16900'
image=strcat(var,'_', '2004-02-16-0100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-16-0100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='17000'
image=strcat(var,'_', '2004-02-16-0200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-16-0200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='17100'
image=strcat(var,'_', '2004-02-16-0300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-16-0300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='17200'
image=strcat(var,'_', '2004-02-16-0400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-16-0400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='17300'
image=strcat(var,'_', '2004-02-16-0500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-16-0500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='17400'
image=strcat(var,'_', '2004-02-16-0600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-16-0600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='17500'
image=strcat(var,'_', '2004-02-16-0700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-16-0700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='17600'
image=strcat(var,'_', '2004-02-16-0800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-16-0800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='17700'
image=strcat(var,'_', '2004-02-16-0900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-16-0900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='17800'
image=strcat(var,'_', '2004-02-16-1000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-16-1000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='17900'
image=strcat(var,'_', '2004-02-16-1100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-16-1100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='18000'
image=strcat(var,'_', '2004-02-16-1200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-16-1200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='18100'
image=strcat(var,'_', '2004-02-16-1300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-16-1300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='18200'
image=strcat(var,'_', '2004-02-16-1400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-16-1400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='18300'
image=strcat(var,'_', '2004-02-16-1500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-16-1500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='18400'
image=strcat(var,'_', '2004-02-16-1600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-16-1600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='18500'
image=strcat(var,'_', '2004-02-16-1700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-16-1700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='18600'
image=strcat(var,'_', '2004-02-16-1800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-16-1800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='18700'
image=strcat(var,'_', '2004-02-16-1900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-16-1900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='18800'
image=strcat(var,'_', '2004-02-16-2000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-16-2000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='18900'
image=strcat(var,'_', '2004-02-16-2100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-16-2100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='19000'
image=strcat(var,'_', '2004-02-16-2200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-16-2200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='19100'
image=strcat(var,'_', '2004-02-16-2300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-16-2300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='19200'
image=strcat(var,'_', '2004-02-17-0000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-17-0000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='19300'
image=strcat(var,'_', '2004-02-17-0100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-17-0100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='19400'
image=strcat(var,'_', '2004-02-17-0200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-17-0200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='19500'
image=strcat(var,'_', '2004-02-17-0300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-17-0300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='19600'
image=strcat(var,'_', '2004-02-17-0400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-17-0400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='19700'
image=strcat(var,'_', '2004-02-17-0500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-17-0500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='19800'
image=strcat(var,'_', '2004-02-17-0600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-17-0600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='19900'
image=strcat(var,'_', '2004-02-17-0700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-17-0700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='20000'
image=strcat(var,'_', '2004-02-17-0800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-17-0800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='20100'
image=strcat(var,'_', '2004-02-17-0900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-17-0900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='20200'
image=strcat(var,'_', '2004-02-17-1000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-17-1000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='20300'
image=strcat(var,'_', '2004-02-17-1100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-17-1100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='20400'
image=strcat(var,'_', '2004-02-17-1200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-17-1200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='20500'
image=strcat(var,'_', '2004-02-17-1300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-17-1300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='20600'
image=strcat(var,'_', '2004-02-17-1400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-17-1400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='20700'
image=strcat(var,'_', '2004-02-17-1500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-17-1500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='20800'
image=strcat(var,'_', '2004-02-17-1600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-17-1600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='20900'
image=strcat(var,'_', '2004-02-17-1700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-17-1700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='21000'
image=strcat(var,'_', '2004-02-17-1800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-17-1800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='21100'
image=strcat(var,'_', '2004-02-17-1900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-17-1900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='21200'
image=strcat(var,'_', '2004-02-17-2000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-17-2000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='21300'
image=strcat(var,'_', '2004-02-17-2100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-17-2100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='21400'
image=strcat(var,'_', '2004-02-17-2200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-17-2200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='21500'
image=strcat(var,'_', '2004-02-17-2300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-17-2300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='21600'
image=strcat(var,'_', '2004-02-18-0000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-18-0000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='21700'
image=strcat(var,'_', '2004-02-18-0100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-18-0100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='21800'
image=strcat(var,'_', '2004-02-18-0200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-18-0200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='21900'
image=strcat(var,'_', '2004-02-18-0300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-18-0300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='22000'
image=strcat(var,'_', '2004-02-18-0400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-18-0400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='22100'
image=strcat(var,'_', '2004-02-18-0500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-18-0500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='22200'
image=strcat(var,'_', '2004-02-18-0600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-18-0600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='22300'
image=strcat(var,'_', '2004-02-18-0700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-18-0700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='22400'
image=strcat(var,'_', '2004-02-18-0800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-18-0800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='22500'
image=strcat(var,'_', '2004-02-18-0900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-18-0900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='22600'
image=strcat(var,'_', '2004-02-18-1000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-18-1000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='22700'
image=strcat(var,'_', '2004-02-18-1100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-18-1100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='22800'
image=strcat(var,'_', '2004-02-18-1200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-18-1200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='22900'
image=strcat(var,'_', '2004-02-18-1300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-18-1300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='23000'
image=strcat(var,'_', '2004-02-18-1400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-18-1400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='23100'
image=strcat(var,'_', '2004-02-18-1500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-18-1500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='23200'
image=strcat(var,'_', '2004-02-18-1600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-18-1600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='23300'
image=strcat(var,'_', '2004-02-18-1700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-18-1700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='23400'
image=strcat(var,'_', '2004-02-18-1800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-18-1800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='23500'
image=strcat(var,'_', '2004-02-18-1900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-18-1900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='23600'
image=strcat(var,'_', '2004-02-18-2000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-18-2000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='23700'
image=strcat(var,'_', '2004-02-18-2100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-18-2100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='23800'
image=strcat(var,'_', '2004-02-18-2200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-18-2200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='23900'
image=strcat(var,'_', '2004-02-18-2300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-18-2300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='24000'
image=strcat(var,'_', '2004-02-19-0000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-19-0000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='24100'
image=strcat(var,'_', '2004-02-19-0100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-19-0100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='24200'
image=strcat(var,'_', '2004-02-19-0200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-19-0200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='24300'
image=strcat(var,'_', '2004-02-19-0300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-19-0300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='24400'
image=strcat(var,'_', '2004-02-19-0400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-19-0400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='24500'
image=strcat(var,'_', '2004-02-19-0500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-19-0500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='24600'
image=strcat(var,'_', '2004-02-19-0600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-19-0600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='24700'
image=strcat(var,'_', '2004-02-19-0700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-19-0700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='24800'
image=strcat(var,'_', '2004-02-19-0800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-19-0800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='24900'
image=strcat(var,'_', '2004-02-19-0900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-19-0900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='25000'
image=strcat(var,'_', '2004-02-19-1000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-19-1000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='25100'
image=strcat(var,'_', '2004-02-19-1100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-19-1100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='25200'
image=strcat(var,'_', '2004-02-19-1200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-19-1200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='25300'
image=strcat(var,'_', '2004-02-19-1300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-19-1300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='25400'
image=strcat(var,'_', '2004-02-19-1400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-19-1400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='25500'
image=strcat(var,'_', '2004-02-19-1500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-19-1500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='25600'
image=strcat(var,'_', '2004-02-19-1600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-19-1600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='25700'
image=strcat(var,'_', '2004-02-19-1700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-19-1700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='25800'
image=strcat(var,'_', '2004-02-19-1800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-19-1800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='25900'
image=strcat(var,'_', '2004-02-19-1900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-19-1900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='26000'
image=strcat(var,'_', '2004-02-19-2000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-19-2000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='26100'
image=strcat(var,'_', '2004-02-19-2100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-19-2100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='26200'
image=strcat(var,'_', '2004-02-19-2200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-19-2200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='26300'
image=strcat(var,'_', '2004-02-19-2300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-19-2300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='26400'
image=strcat(var,'_', '2004-02-20-0000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-20-0000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='26500'
image=strcat(var,'_', '2004-02-20-0100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-20-0100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='26600'
image=strcat(var,'_', '2004-02-20-0200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-20-0200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='26700'
image=strcat(var,'_', '2004-02-20-0300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-20-0300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='26800'
image=strcat(var,'_', '2004-02-20-0400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-20-0400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='26900'
image=strcat(var,'_', '2004-02-20-0500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-20-0500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='27000'
image=strcat(var,'_', '2004-02-20-0600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-20-0600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='27100'
image=strcat(var,'_', '2004-02-20-0700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-20-0700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='27200'
image=strcat(var,'_', '2004-02-20-0800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-20-0800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='27300'
image=strcat(var,'_', '2004-02-20-0900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-20-0900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='27400'
image=strcat(var,'_', '2004-02-20-1000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-20-1000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='27500'
image=strcat(var,'_', '2004-02-20-1100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-20-1100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='27600'
image=strcat(var,'_', '2004-02-20-1200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-20-1200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='27700'
image=strcat(var,'_', '2004-02-20-1300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-20-1300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='27800'
image=strcat(var,'_', '2004-02-20-1400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-20-1400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='27900'
image=strcat(var,'_', '2004-02-20-1500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-20-1500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='28000'
image=strcat(var,'_', '2004-02-20-1600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-20-1600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='28100'
image=strcat(var,'_', '2004-02-20-1700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-20-1700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='28200'
image=strcat(var,'_', '2004-02-20-1800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-20-1800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='28300'
image=strcat(var,'_', '2004-02-20-1900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-20-1900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='28400'
image=strcat(var,'_', '2004-02-20-2000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-20-2000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='28500'
image=strcat(var,'_', '2004-02-20-2100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-20-2100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='28600'
image=strcat(var,'_', '2004-02-20-2200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-20-2200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='28700'
image=strcat(var,'_', '2004-02-20-2300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-20-2300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='28800'
image=strcat(var,'_', '2004-02-21-0000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-21-0000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='28900'
image=strcat(var,'_', '2004-02-21-0100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-21-0100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='29000'
image=strcat(var,'_', '2004-02-21-0200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-21-0200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='29100'
image=strcat(var,'_', '2004-02-21-0300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-21-0300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='29200'
image=strcat(var,'_', '2004-02-21-0400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-21-0400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='29300'
image=strcat(var,'_', '2004-02-21-0500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-21-0500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='29400'
image=strcat(var,'_', '2004-02-21-0600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-21-0600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='29500'
image=strcat(var,'_', '2004-02-21-0700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-21-0700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='29600'
image=strcat(var,'_', '2004-02-21-0800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-21-0800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='29700'
image=strcat(var,'_', '2004-02-21-0900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-21-0900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='29800'
image=strcat(var,'_', '2004-02-21-1000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-21-1000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='29900'
image=strcat(var,'_', '2004-02-21-1100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-21-1100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='30000'
image=strcat(var,'_', '2004-02-21-1200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-21-1200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='30100'
image=strcat(var,'_', '2004-02-21-1300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-21-1300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='30200'
image=strcat(var,'_', '2004-02-21-1400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-21-1400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='30300'
image=strcat(var,'_', '2004-02-21-1500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-21-1500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='30400'
image=strcat(var,'_', '2004-02-21-1600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-21-1600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='30500'
image=strcat(var,'_', '2004-02-21-1700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-21-1700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='30600'
image=strcat(var,'_', '2004-02-21-1800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-21-1800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='30700'
image=strcat(var,'_', '2004-02-21-1900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-21-1900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='30800'
image=strcat(var,'_', '2004-02-21-2000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-21-2000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='30900'
image=strcat(var,'_', '2004-02-21-2100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-21-2100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='31000'
image=strcat(var,'_', '2004-02-21-2200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-21-2200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='31100'
image=strcat(var,'_', '2004-02-21-2300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-21-2300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='31200'
image=strcat(var,'_', '2004-02-22-0000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-22-0000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='31300'
image=strcat(var,'_', '2004-02-22-0100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-22-0100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='31400'
image=strcat(var,'_', '2004-02-22-0200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-22-0200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='31500'
image=strcat(var,'_', '2004-02-22-0300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-22-0300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='31600'
image=strcat(var,'_', '2004-02-22-0400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-22-0400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='31700'
image=strcat(var,'_', '2004-02-22-0500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-22-0500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='31800'
image=strcat(var,'_', '2004-02-22-0600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-22-0600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='31900'
image=strcat(var,'_', '2004-02-22-0700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-22-0700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='32000'
image=strcat(var,'_', '2004-02-22-0800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-22-0800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='32100'
image=strcat(var,'_', '2004-02-22-0900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-22-0900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='32200'
image=strcat(var,'_', '2004-02-22-1000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-22-1000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='32300'
image=strcat(var,'_', '2004-02-22-1100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-22-1100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='32400'
image=strcat(var,'_', '2004-02-22-1200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-22-1200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='32500'
image=strcat(var,'_', '2004-02-22-1300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-22-1300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='32600'
image=strcat(var,'_', '2004-02-22-1400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-22-1400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='32700'
image=strcat(var,'_', '2004-02-22-1500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-22-1500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='32800'
image=strcat(var,'_', '2004-02-22-1600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-22-1600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='32900'
image=strcat(var,'_', '2004-02-22-1700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-22-1700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='33000'
image=strcat(var,'_', '2004-02-22-1800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-22-1800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='33100'
image=strcat(var,'_', '2004-02-22-1900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-22-1900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='33200'
image=strcat(var,'_', '2004-02-22-2000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-22-2000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='33300'
image=strcat(var,'_', '2004-02-22-2100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-22-2100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='33400'
image=strcat(var,'_', '2004-02-22-2200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-22-2200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='33500'
image=strcat(var,'_', '2004-02-22-2300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-22-2300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='33600'
image=strcat(var,'_', '2004-02-23-0000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-23-0000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='33700'
image=strcat(var,'_', '2004-02-23-0100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-23-0100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='33800'
image=strcat(var,'_', '2004-02-23-0200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-23-0200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='33900'
image=strcat(var,'_', '2004-02-23-0300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-23-0300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='34000'
image=strcat(var,'_', '2004-02-23-0400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-23-0400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='34100'
image=strcat(var,'_', '2004-02-23-0500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-23-0500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='34200'
image=strcat(var,'_', '2004-02-23-0600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-23-0600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='34300'
image=strcat(var,'_', '2004-02-23-0700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-23-0700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='34400'
image=strcat(var,'_', '2004-02-23-0800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-23-0800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='34500'
image=strcat(var,'_', '2004-02-23-0900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-23-0900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='34600'
image=strcat(var,'_', '2004-02-23-1000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-23-1000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='34700'
image=strcat(var,'_', '2004-02-23-1100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-23-1100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='34800'
image=strcat(var,'_', '2004-02-23-1200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-23-1200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='34900'
image=strcat(var,'_', '2004-02-23-1300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-23-1300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='35000'
image=strcat(var,'_', '2004-02-23-1400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-23-1400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='35100'
image=strcat(var,'_', '2004-02-23-1500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-23-1500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='35200'
image=strcat(var,'_', '2004-02-23-1600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-23-1600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='35300'
image=strcat(var,'_', '2004-02-23-1700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-23-1700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='35400'
image=strcat(var,'_', '2004-02-23-1800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-23-1800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='35500'
image=strcat(var,'_', '2004-02-23-1900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-23-1900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='35600'
image=strcat(var,'_', '2004-02-23-2000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-23-2000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='35700'
image=strcat(var,'_', '2004-02-23-2100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-23-2100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='35800'
image=strcat(var,'_', '2004-02-23-2200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-23-2200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='35900'
image=strcat(var,'_', '2004-02-23-2300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-23-2300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='36000'
image=strcat(var,'_', '2004-02-24-0000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-24-0000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='36100'
image=strcat(var,'_', '2004-02-24-0100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-24-0100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='36200'
image=strcat(var,'_', '2004-02-24-0200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-24-0200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='36300'
image=strcat(var,'_', '2004-02-24-0300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-24-0300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='36400'
image=strcat(var,'_', '2004-02-24-0400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-24-0400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='36500'
image=strcat(var,'_', '2004-02-24-0500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-24-0500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='36600'
image=strcat(var,'_', '2004-02-24-0600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-24-0600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='36700'
image=strcat(var,'_', '2004-02-24-0700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-24-0700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='36800'
image=strcat(var,'_', '2004-02-24-0800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-24-0800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='36900'
image=strcat(var,'_', '2004-02-24-0900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-24-0900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='37000'
image=strcat(var,'_', '2004-02-24-1000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-24-1000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='37100'
image=strcat(var,'_', '2004-02-24-1100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-24-1100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='37200'
image=strcat(var,'_', '2004-02-24-1200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-24-1200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='37300'
image=strcat(var,'_', '2004-02-24-1300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-24-1300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='37400'
image=strcat(var,'_', '2004-02-24-1400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-24-1400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='37500'
image=strcat(var,'_', '2004-02-24-1500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-24-1500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='37600'
image=strcat(var,'_', '2004-02-24-1600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-24-1600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='37700'
image=strcat(var,'_', '2004-02-24-1700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-24-1700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='37800'
image=strcat(var,'_', '2004-02-24-1800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-24-1800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='37900'
image=strcat(var,'_', '2004-02-24-1900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-24-1900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='38000'
image=strcat(var,'_', '2004-02-24-2000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-24-2000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='38100'
image=strcat(var,'_', '2004-02-24-2100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-24-2100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='38200'
image=strcat(var,'_', '2004-02-24-2200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-24-2200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='38300'
image=strcat(var,'_', '2004-02-24-2300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-24-2300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='38400'
image=strcat(var,'_', '2004-02-25-0000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-25-0000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='38500'
image=strcat(var,'_', '2004-02-25-0100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-25-0100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='38600'
image=strcat(var,'_', '2004-02-25-0200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-25-0200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='38700'
image=strcat(var,'_', '2004-02-25-0300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-25-0300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='38800'
image=strcat(var,'_', '2004-02-25-0400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-25-0400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='38900'
image=strcat(var,'_', '2004-02-25-0500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-25-0500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='39000'
image=strcat(var,'_', '2004-02-25-0600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-25-0600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='39100'
image=strcat(var,'_', '2004-02-25-0700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-25-0700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='39200'
image=strcat(var,'_', '2004-02-25-0800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-25-0800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='39300'
image=strcat(var,'_', '2004-02-25-0900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-25-0900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='39400'
image=strcat(var,'_', '2004-02-25-1000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-25-1000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='39500'
image=strcat(var,'_', '2004-02-25-1100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-25-1100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='39600'
image=strcat(var,'_', '2004-02-25-1200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-25-1200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='39700'
image=strcat(var,'_', '2004-02-25-1300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-25-1300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='39800'
image=strcat(var,'_', '2004-02-25-1400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-25-1400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='39900'
image=strcat(var,'_', '2004-02-25-1500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-25-1500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='40000'
image=strcat(var,'_', '2004-02-25-1600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-25-1600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='40100'
image=strcat(var,'_', '2004-02-25-1700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-25-1700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='40200'
image=strcat(var,'_', '2004-02-25-1800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-25-1800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='40300'
image=strcat(var,'_', '2004-02-25-1900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-25-1900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='40400'
image=strcat(var,'_', '2004-02-25-2000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-25-2000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='40500'
image=strcat(var,'_', '2004-02-25-2100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-25-2100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='40600'
image=strcat(var,'_', '2004-02-25-2200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-25-2200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='40700'
image=strcat(var,'_', '2004-02-25-2300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-25-2300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='40800'
image=strcat(var,'_', '2004-02-26-0000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-26-0000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='40900'
image=strcat(var,'_', '2004-02-26-0100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-26-0100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='41000'
image=strcat(var,'_', '2004-02-26-0200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-26-0200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='41100'
image=strcat(var,'_', '2004-02-26-0300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-26-0300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='41200'
image=strcat(var,'_', '2004-02-26-0400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-26-0400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='41300'
image=strcat(var,'_', '2004-02-26-0500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-26-0500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='41400'
image=strcat(var,'_', '2004-02-26-0600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-26-0600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='41500'
image=strcat(var,'_', '2004-02-26-0700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-26-0700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='41600'
image=strcat(var,'_', '2004-02-26-0800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-26-0800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='41700'
image=strcat(var,'_', '2004-02-26-0900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-26-0900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='41800'
image=strcat(var,'_', '2004-02-26-1000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-26-1000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='41900'
image=strcat(var,'_', '2004-02-26-1100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-26-1100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='42000'
image=strcat(var,'_', '2004-02-26-1200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-26-1200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='42100'
image=strcat(var,'_', '2004-02-26-1300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-26-1300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='42200'
image=strcat(var,'_', '2004-02-26-1400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-26-1400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='42300'
image=strcat(var,'_', '2004-02-26-1500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-26-1500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='42400'
image=strcat(var,'_', '2004-02-26-1600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-26-1600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='42500'
image=strcat(var,'_', '2004-02-26-1700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-26-1700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='42600'
image=strcat(var,'_', '2004-02-26-1800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-26-1800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='42700'
image=strcat(var,'_', '2004-02-26-1900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-26-1900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='42800'
image=strcat(var,'_', '2004-02-26-2000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-26-2000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='42900'
image=strcat(var,'_', '2004-02-26-2100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-26-2100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='43000'
image=strcat(var,'_', '2004-02-26-2200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-26-2200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='43100'
image=strcat(var,'_', '2004-02-26-2300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-26-2300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='43200'
image=strcat(var,'_', '2004-02-27-0000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-27-0000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='43300'
image=strcat(var,'_', '2004-02-27-0100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-27-0100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='43400'
image=strcat(var,'_', '2004-02-27-0200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-27-0200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='43500'
image=strcat(var,'_', '2004-02-27-0300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-27-0300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='43600'
image=strcat(var,'_', '2004-02-27-0400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-27-0400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='43700'
image=strcat(var,'_', '2004-02-27-0500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-27-0500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='43800'
image=strcat(var,'_', '2004-02-27-0600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-27-0600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='43900'
image=strcat(var,'_', '2004-02-27-0700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-27-0700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='44000'
image=strcat(var,'_', '2004-02-27-0800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-27-0800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='44100'
image=strcat(var,'_', '2004-02-27-0900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-27-0900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='44200'
image=strcat(var,'_', '2004-02-27-1000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-27-1000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='44300'
image=strcat(var,'_', '2004-02-27-1100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-27-1100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='44400'
image=strcat(var,'_', '2004-02-27-1200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-27-1200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='44500'
image=strcat(var,'_', '2004-02-27-1300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-27-1300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='44600'
image=strcat(var,'_', '2004-02-27-1400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-27-1400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='44700'
image=strcat(var,'_', '2004-02-27-1500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-27-1500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='44800'
image=strcat(var,'_', '2004-02-27-1600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-27-1600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='44900'
image=strcat(var,'_', '2004-02-27-1700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-27-1700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='45000'
image=strcat(var,'_', '2004-02-27-1800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-27-1800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='45100'
image=strcat(var,'_', '2004-02-27-1900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-27-1900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='45200'
image=strcat(var,'_', '2004-02-27-2000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-27-2000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='45300'
image=strcat(var,'_', '2004-02-27-2100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-27-2100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='45400'
image=strcat(var,'_', '2004-02-27-2200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-27-2200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='45500'
image=strcat(var,'_', '2004-02-27-2300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-27-2300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='45600'
image=strcat(var,'_', '2004-02-28-0000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-28-0000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='45700'
image=strcat(var,'_', '2004-02-28-0100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-28-0100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='45800'
image=strcat(var,'_', '2004-02-28-0200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-28-0200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='45900'
image=strcat(var,'_', '2004-02-28-0300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-28-0300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='46000'
image=strcat(var,'_', '2004-02-28-0400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-28-0400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='46100'
image=strcat(var,'_', '2004-02-28-0500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-28-0500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='46200'
image=strcat(var,'_', '2004-02-28-0600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-28-0600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='46300'
image=strcat(var,'_', '2004-02-28-0700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-28-0700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='46400'
image=strcat(var,'_', '2004-02-28-0800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-28-0800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='46500'
image=strcat(var,'_', '2004-02-28-0900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-28-0900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='46600'
image=strcat(var,'_', '2004-02-28-1000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-28-1000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='46700'
image=strcat(var,'_', '2004-02-28-1100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-28-1100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='46800'
image=strcat(var,'_', '2004-02-28-1200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-28-1200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='46900'
image=strcat(var,'_', '2004-02-28-1300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-28-1300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='47000'
image=strcat(var,'_', '2004-02-28-1400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-28-1400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='47100'
image=strcat(var,'_', '2004-02-28-1500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-28-1500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='47200'
image=strcat(var,'_', '2004-02-28-1600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-28-1600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='47300'
image=strcat(var,'_', '2004-02-28-1700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-28-1700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='47400'
image=strcat(var,'_', '2004-02-28-1800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-28-1800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='47500'
image=strcat(var,'_', '2004-02-28-1900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-28-1900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='47600'
image=strcat(var,'_', '2004-02-28-2000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-28-2000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='47700'
image=strcat(var,'_', '2004-02-28-2100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-28-2100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='47800'
image=strcat(var,'_', '2004-02-28-2200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-28-2200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='47900'
image=strcat(var,'_', '2004-02-28-2300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-28-2300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='48000'
image=strcat(var,'_', '2004-02-29-0000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-29-0000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='48100'
image=strcat(var,'_', '2004-02-29-0100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-29-0100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='48200'
image=strcat(var,'_', '2004-02-29-0200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-29-0200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='48300'
image=strcat(var,'_', '2004-02-29-0300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-29-0300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='48400'
image=strcat(var,'_', '2004-02-29-0400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-29-0400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='48500'
image=strcat(var,'_', '2004-02-29-0500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-29-0500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='48600'
image=strcat(var,'_', '2004-02-29-0600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-29-0600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='48700'
image=strcat(var,'_', '2004-02-29-0700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-29-0700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='48800'
image=strcat(var,'_', '2004-02-29-0800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-29-0800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='48900'
image=strcat(var,'_', '2004-02-29-0900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-29-0900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='49000'
image=strcat(var,'_', '2004-02-29-1000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-29-1000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='49100'
image=strcat(var,'_', '2004-02-29-1100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-29-1100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='49200'
image=strcat(var,'_', '2004-02-29-1200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-29-1200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='49300'
image=strcat(var,'_', '2004-02-29-1300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-29-1300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='49400'
image=strcat(var,'_', '2004-02-29-1400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-29-1400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='49500'
image=strcat(var,'_', '2004-02-29-1500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-29-1500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='49600'
image=strcat(var,'_', '2004-02-29-1600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-29-1600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='49700'
image=strcat(var,'_', '2004-02-29-1700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-29-1700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='49800'
image=strcat(var,'_', '2004-02-29-1800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-29-1800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='49900'
image=strcat(var,'_', '2004-02-29-1900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-29-1900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='50000'
image=strcat(var,'_', '2004-02-29-2000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-29-2000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='50100'
image=strcat(var,'_', '2004-02-29-2100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-29-2100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='50200'
image=strcat(var,'_', '2004-02-29-2200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-29-2200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='50300'
image=strcat(var,'_', '2004-02-29-2300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-29-2300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='50400'
image=strcat(var,'_', '2004-03-01-0000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-01-0000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='50500'
image=strcat(var,'_', '2004-03-01-0100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-01-0100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='50600'
image=strcat(var,'_', '2004-03-01-0200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-01-0200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='50700'
image=strcat(var,'_', '2004-03-01-0300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-01-0300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='50800'
image=strcat(var,'_', '2004-03-01-0400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-01-0400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='50900'
image=strcat(var,'_', '2004-03-01-0500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-01-0500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='51000'
image=strcat(var,'_', '2004-03-01-0600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-01-0600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='51100'
image=strcat(var,'_', '2004-03-01-0700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-01-0700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='51200'
image=strcat(var,'_', '2004-03-01-0800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-01-0800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='51300'
image=strcat(var,'_', '2004-03-01-0900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-01-0900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='51400'
image=strcat(var,'_', '2004-03-01-1000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-01-1000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='51500'
image=strcat(var,'_', '2004-03-01-1100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-01-1100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='51600'
image=strcat(var,'_', '2004-03-01-1200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-01-1200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='51700'
image=strcat(var,'_', '2004-03-01-1300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-01-1300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='51800'
image=strcat(var,'_', '2004-03-01-1400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-01-1400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='51900'
image=strcat(var,'_', '2004-03-01-1500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-01-1500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='52000'
image=strcat(var,'_', '2004-03-01-1600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-01-1600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='52100'
image=strcat(var,'_', '2004-03-01-1700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-01-1700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='52200'
image=strcat(var,'_', '2004-03-01-1800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-01-1800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='52300'
image=strcat(var,'_', '2004-03-01-1900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-01-1900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='52400'
image=strcat(var,'_', '2004-03-01-2000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-01-2000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='52500'
image=strcat(var,'_', '2004-03-01-2100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-01-2100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='52600'
image=strcat(var,'_', '2004-03-01-2200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-01-2200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='52700'
image=strcat(var,'_', '2004-03-01-2300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-01-2300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='52800'
image=strcat(var,'_', '2004-03-02-0000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-02-0000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='52900'
image=strcat(var,'_', '2004-03-02-0100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-02-0100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='53000'
image=strcat(var,'_', '2004-03-02-0200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-02-0200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='53100'
image=strcat(var,'_', '2004-03-02-0300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-02-0300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='53200'
image=strcat(var,'_', '2004-03-02-0400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-02-0400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='53300'
image=strcat(var,'_', '2004-03-02-0500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-02-0500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='53400'
image=strcat(var,'_', '2004-03-02-0600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-02-0600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='53500'
image=strcat(var,'_', '2004-03-02-0700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-02-0700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='53600'
image=strcat(var,'_', '2004-03-02-0800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-02-0800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='53700'
image=strcat(var,'_', '2004-03-02-0900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-02-0900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='53800'
image=strcat(var,'_', '2004-03-02-1000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-02-1000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='53900'
image=strcat(var,'_', '2004-03-02-1100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-02-1100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='54000'
image=strcat(var,'_', '2004-03-02-1200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-02-1200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='54100'
image=strcat(var,'_', '2004-03-02-1300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-02-1300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='54200'
image=strcat(var,'_', '2004-03-02-1400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-02-1400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='54300'
image=strcat(var,'_', '2004-03-02-1500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-02-1500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='54400'
image=strcat(var,'_', '2004-03-02-1600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-02-1600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='54500'
image=strcat(var,'_', '2004-03-02-1700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-02-1700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='54600'
image=strcat(var,'_', '2004-03-02-1800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-02-1800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='54700'
image=strcat(var,'_', '2004-03-02-1900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-02-1900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='54800'
image=strcat(var,'_', '2004-03-02-2000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-02-2000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='54900'
image=strcat(var,'_', '2004-03-02-2100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-02-2100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='55000'
image=strcat(var,'_', '2004-03-02-2200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-02-2200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='55100'
image=strcat(var,'_', '2004-03-02-2300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-02-2300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='55200'
image=strcat(var,'_', '2004-03-03-0000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-03-0000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='55300'
image=strcat(var,'_', '2004-03-03-0100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-03-0100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='55400'
image=strcat(var,'_', '2004-03-03-0200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-03-0200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='55500'
image=strcat(var,'_', '2004-03-03-0300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-03-0300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='55600'
image=strcat(var,'_', '2004-03-03-0400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-03-0400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='55700'
image=strcat(var,'_', '2004-03-03-0500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-03-0500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='55800'
image=strcat(var,'_', '2004-03-03-0600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-03-0600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='55900'
image=strcat(var,'_', '2004-03-03-0700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-03-0700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='56000'
image=strcat(var,'_', '2004-03-03-0800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-03-0800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='56100'
image=strcat(var,'_', '2004-03-03-0900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-03-0900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='56200'
image=strcat(var,'_', '2004-03-03-1000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-03-1000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='56300'
image=strcat(var,'_', '2004-03-03-1100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-03-1100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='56400'
image=strcat(var,'_', '2004-03-03-1200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-03-1200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='56500'
image=strcat(var,'_', '2004-03-03-1300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-03-1300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='56600'
image=strcat(var,'_', '2004-03-03-1400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-03-1400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='56700'
image=strcat(var,'_', '2004-03-03-1500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-03-1500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='56800'
image=strcat(var,'_', '2004-03-03-1600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-03-1600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='56900'
image=strcat(var,'_', '2004-03-03-1700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-03-1700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='57000'
image=strcat(var,'_', '2004-03-03-1800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-03-1800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='57100'
image=strcat(var,'_', '2004-03-03-1900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-03-1900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='57200'
image=strcat(var,'_', '2004-03-03-2000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-03-2000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='57300'
image=strcat(var,'_', '2004-03-03-2100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-03-2100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='57400'
image=strcat(var,'_', '2004-03-03-2200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-03-2200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='57500'
image=strcat(var,'_', '2004-03-03-2300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-03-2300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='57600'
image=strcat(var,'_', '2004-03-04-0000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-04-0000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='57700'
image=strcat(var,'_', '2004-03-04-0100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-04-0100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='57800'
image=strcat(var,'_', '2004-03-04-0200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-04-0200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='57900'
image=strcat(var,'_', '2004-03-04-0300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-04-0300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='58000'
image=strcat(var,'_', '2004-03-04-0400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-04-0400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='58100'
image=strcat(var,'_', '2004-03-04-0500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-04-0500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='58200'
image=strcat(var,'_', '2004-03-04-0600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-04-0600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='58300'
image=strcat(var,'_', '2004-03-04-0700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-04-0700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='58400'
image=strcat(var,'_', '2004-03-04-0800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-04-0800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='58500'
image=strcat(var,'_', '2004-03-04-0900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-04-0900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='58600'
image=strcat(var,'_', '2004-03-04-1000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-04-1000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='58700'
image=strcat(var,'_', '2004-03-04-1100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-04-1100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='58800'
image=strcat(var,'_', '2004-03-04-1200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-04-1200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='58900'
image=strcat(var,'_', '2004-03-04-1300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-04-1300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='59000'
image=strcat(var,'_', '2004-03-04-1400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-04-1400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='59100'
image=strcat(var,'_', '2004-03-04-1500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-04-1500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='59200'
image=strcat(var,'_', '2004-03-04-1600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-04-1600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='59300'
image=strcat(var,'_', '2004-03-04-1700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-04-1700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='59400'
image=strcat(var,'_', '2004-03-04-1800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-04-1800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='59500'
image=strcat(var,'_', '2004-03-04-1900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-04-1900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='59600'
image=strcat(var,'_', '2004-03-04-2000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-04-2000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='59700'
image=strcat(var,'_', '2004-03-04-2100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-04-2100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='59800'
image=strcat(var,'_', '2004-03-04-2200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-04-2200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='59900'
image=strcat(var,'_', '2004-03-04-2300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-04-2300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='60000'
image=strcat(var,'_', '2004-03-05-0000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-05-0000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='60100'
image=strcat(var,'_', '2004-03-05-0100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-05-0100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='60200'
image=strcat(var,'_', '2004-03-05-0200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-05-0200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='60300'
image=strcat(var,'_', '2004-03-05-0300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-05-0300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='60400'
image=strcat(var,'_', '2004-03-05-0400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-05-0400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='60500'
image=strcat(var,'_', '2004-03-05-0500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-05-0500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='60600'
image=strcat(var,'_', '2004-03-05-0600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-05-0600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='60700'
image=strcat(var,'_', '2004-03-05-0700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-05-0700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='60800'
image=strcat(var,'_', '2004-03-05-0800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-05-0800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='60900'
image=strcat(var,'_', '2004-03-05-0900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-05-0900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='61000'
image=strcat(var,'_', '2004-03-05-1000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-05-1000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='61100'
image=strcat(var,'_', '2004-03-05-1100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-05-1100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='61200'
image=strcat(var,'_', '2004-03-05-1200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-05-1200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='61300'
image=strcat(var,'_', '2004-03-05-1300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-05-1300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='61400'
image=strcat(var,'_', '2004-03-05-1400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-05-1400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='61500'
image=strcat(var,'_', '2004-03-05-1500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-05-1500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='61600'
image=strcat(var,'_', '2004-03-05-1600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-05-1600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='61700'
image=strcat(var,'_', '2004-03-05-1700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-05-1700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='61800'
image=strcat(var,'_', '2004-03-05-1800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-05-1800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='61900'
image=strcat(var,'_', '2004-03-05-1900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-05-1900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='62000'
image=strcat(var,'_', '2004-03-05-2000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-05-2000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='62100'
image=strcat(var,'_', '2004-03-05-2100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-05-2100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='62200'
image=strcat(var,'_', '2004-03-05-2200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-05-2200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='62300'
image=strcat(var,'_', '2004-03-05-2300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-05-2300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='62400'
image=strcat(var,'_', '2004-03-06-0000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-06-0000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='62500'
image=strcat(var,'_', '2004-03-06-0100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-06-0100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='62600'
image=strcat(var,'_', '2004-03-06-0200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-06-0200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='62700'
image=strcat(var,'_', '2004-03-06-0300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-06-0300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='62800'
image=strcat(var,'_', '2004-03-06-0400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-06-0400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='62900'
image=strcat(var,'_', '2004-03-06-0500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-06-0500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='63000'
image=strcat(var,'_', '2004-03-06-0600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-06-0600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='63100'
image=strcat(var,'_', '2004-03-06-0700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-06-0700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='63200'
image=strcat(var,'_', '2004-03-06-0800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-06-0800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='63300'
image=strcat(var,'_', '2004-03-06-0900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-06-0900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='63400'
image=strcat(var,'_', '2004-03-06-1000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-06-1000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='63500'
image=strcat(var,'_', '2004-03-06-1100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-06-1100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='63600'
image=strcat(var,'_', '2004-03-06-1200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-06-1200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='63700'
image=strcat(var,'_', '2004-03-06-1300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-06-1300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='63800'
image=strcat(var,'_', '2004-03-06-1400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-06-1400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='63900'
image=strcat(var,'_', '2004-03-06-1500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-06-1500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='64000'
image=strcat(var,'_', '2004-03-06-1600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-06-1600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='64100'
image=strcat(var,'_', '2004-03-06-1700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-06-1700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='64200'
image=strcat(var,'_', '2004-03-06-1800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-06-1800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='64300'
image=strcat(var,'_', '2004-03-06-1900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-06-1900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='64400'
image=strcat(var,'_', '2004-03-06-2000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-06-2000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='64500'
image=strcat(var,'_', '2004-03-06-2100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-06-2100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='64600'
image=strcat(var,'_', '2004-03-06-2200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-06-2200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='64700'
image=strcat(var,'_', '2004-03-06-2300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-06-2300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='64800'
image=strcat(var,'_', '2004-03-07-0000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-07-0000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='64900'
image=strcat(var,'_', '2004-03-07-0100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-07-0100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='65000'
image=strcat(var,'_', '2004-03-07-0200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-07-0200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='65100'
image=strcat(var,'_', '2004-03-07-0300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-07-0300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='65200'
image=strcat(var,'_', '2004-03-07-0400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-07-0400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='65300'
image=strcat(var,'_', '2004-03-07-0500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-07-0500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='65400'
image=strcat(var,'_', '2004-03-07-0600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-07-0600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='65500'
image=strcat(var,'_', '2004-03-07-0700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-07-0700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='65600'
image=strcat(var,'_', '2004-03-07-0800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-07-0800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='65700'
image=strcat(var,'_', '2004-03-07-0900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-07-0900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='65800'
image=strcat(var,'_', '2004-03-07-1000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-07-1000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='65900'
image=strcat(var,'_', '2004-03-07-1100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-07-1100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='66000'
image=strcat(var,'_', '2004-03-07-1200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-07-1200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='66100'
image=strcat(var,'_', '2004-03-07-1300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-07-1300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='66200'
image=strcat(var,'_', '2004-03-07-1400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-07-1400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='66300'
image=strcat(var,'_', '2004-03-07-1500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-07-1500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='66400'
image=strcat(var,'_', '2004-03-07-1600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-07-1600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='66500'
image=strcat(var,'_', '2004-03-07-1700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-07-1700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='66600'
image=strcat(var,'_', '2004-03-07-1800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-07-1800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='66700'
image=strcat(var,'_', '2004-03-07-1900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-07-1900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='66800'
image=strcat(var,'_', '2004-03-07-2000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-07-2000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='66900'
image=strcat(var,'_', '2004-03-07-2100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-07-2100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='67000'
image=strcat(var,'_', '2004-03-07-2200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-07-2200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='67100'
image=strcat(var,'_', '2004-03-07-2300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-07-2300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='67200'
image=strcat(var,'_', '2004-03-08-0000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-08-0000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='67300'
image=strcat(var,'_', '2004-03-08-0100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-08-0100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='67400'
image=strcat(var,'_', '2004-03-08-0200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-08-0200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='67500'
image=strcat(var,'_', '2004-03-08-0300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-08-0300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='67600'
image=strcat(var,'_', '2004-03-08-0400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-08-0400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='67700'
image=strcat(var,'_', '2004-03-08-0500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-08-0500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='67800'
image=strcat(var,'_', '2004-03-08-0600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-08-0600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='67900'
image=strcat(var,'_', '2004-03-08-0700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-08-0700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='68000'
image=strcat(var,'_', '2004-03-08-0800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-08-0800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='68100'
image=strcat(var,'_', '2004-03-08-0900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-08-0900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='68200'
image=strcat(var,'_', '2004-03-08-1000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-08-1000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='68300'
image=strcat(var,'_', '2004-03-08-1100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-08-1100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='68400'
image=strcat(var,'_', '2004-03-08-1200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-08-1200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='68500'
image=strcat(var,'_', '2004-03-08-1300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-08-1300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='68600'
image=strcat(var,'_', '2004-03-08-1400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-08-1400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='68700'
image=strcat(var,'_', '2004-03-08-1500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-08-1500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='68800'
image=strcat(var,'_', '2004-03-08-1600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-08-1600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='68900'
image=strcat(var,'_', '2004-03-08-1700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-08-1700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='69000'
image=strcat(var,'_', '2004-03-08-1800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-08-1800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='69100'
image=strcat(var,'_', '2004-03-08-1900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-08-1900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='69200'
image=strcat(var,'_', '2004-03-08-2000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-08-2000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='69300'
image=strcat(var,'_', '2004-03-08-2100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-08-2100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='69400'
image=strcat(var,'_', '2004-03-08-2200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-08-2200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='69500'
image=strcat(var,'_', '2004-03-08-2300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-08-2300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='69600'
image=strcat(var,'_', '2004-03-09-0000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-09-0000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='69700'
image=strcat(var,'_', '2004-03-09-0100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-09-0100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='69800'
image=strcat(var,'_', '2004-03-09-0200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-09-0200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='69900'
image=strcat(var,'_', '2004-03-09-0300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-09-0300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='70000'
image=strcat(var,'_', '2004-03-09-0400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-09-0400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='70100'
image=strcat(var,'_', '2004-03-09-0500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-09-0500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='70200'
image=strcat(var,'_', '2004-03-09-0600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-09-0600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='70300'
image=strcat(var,'_', '2004-03-09-0700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-09-0700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='70400'
image=strcat(var,'_', '2004-03-09-0800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-09-0800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='70500'
image=strcat(var,'_', '2004-03-09-0900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-09-0900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='70600'
image=strcat(var,'_', '2004-03-09-1000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-09-1000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='70700'
image=strcat(var,'_', '2004-03-09-1100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-09-1100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='70800'
image=strcat(var,'_', '2004-03-09-1200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-09-1200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='70900'
image=strcat(var,'_', '2004-03-09-1300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-09-1300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='71000'
image=strcat(var,'_', '2004-03-09-1400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-09-1400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='71100'
image=strcat(var,'_', '2004-03-09-1500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-09-1500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='71200'
image=strcat(var,'_', '2004-03-09-1600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-09-1600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='71300'
image=strcat(var,'_', '2004-03-09-1700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-09-1700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='71400'
image=strcat(var,'_', '2004-03-09-1800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-09-1800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='71500'
image=strcat(var,'_', '2004-03-09-1900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-09-1900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='71600'
image=strcat(var,'_', '2004-03-09-2000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-09-2000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='71700'
image=strcat(var,'_', '2004-03-09-2100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-09-2100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='71800'
image=strcat(var,'_', '2004-03-09-2200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-09-2200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='71900'
image=strcat(var,'_', '2004-03-09-2300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-03-09-2300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([60.0,79.0,60.0,79.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij

