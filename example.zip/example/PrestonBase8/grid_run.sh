qsub -l h_vmem=6G -o /nfs/home/kerryn/VTUF_Runs/PrestonBase/PrestonBase8/PrestonBase_output.txt -m baes -M kerry.nice@monash.edu /nfs/home/kerryn/VTUF_Runs/PrestonBase/PrestonBase8/run.sh
