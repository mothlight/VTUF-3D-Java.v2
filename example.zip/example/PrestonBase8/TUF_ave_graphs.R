library(sqldf)

readTableFromZip <- function(filename,header = FALSE, skip=startRow,col.names=colnames, nrows=totalRows) 
{
  if (  file.exists("out.zip") )
  {
    data_table <- read.table(unz("out.zip", filename),header = FALSE, skip=startRow,col.names=colnames, nrows=totalRows) 
  }
  else 
  {
      data_table <- read.table(filename,header = FALSE, skip=startRow,col.names=colnames, nrows=totalRows) 
  }
  
  return(data_table)
}

parametersFilename <- "parameters.dat"
parameters_table <- file(parametersFilename, "rt")
readLines(parameters_table, 1) # Read one line

parametersLine2  <- readLines(parameters_table, 1) # Read one line 
parametersLine2Unlist <- unlist(strsplit(parametersLine2, " ", fixed = FALSE, perl = FALSE, useBytes = FALSE))

startDayJulian <- parametersLine2Unlist[1]
#startDayJulian <- as.numeric(parametersLine2Unlist[1])
startDayDate <- as.Date(startDayJulian, "%j")
startDay <- as.numeric(format(startDayDate, "%d"))

startMonth <- months(startDayDate, abbreviate = TRUE)
 
forcingFilename <- "forcing.dat"
forcing_table <- file(forcingFilename, "rt")
forcingLine1 <- readLines(forcing_table, 1) # Read one line 
forcingLine1Split <- unlist(strsplit(forcingLine1, " ", fixed = FALSE, perl = FALSE, useBytes = FALSE))

numberOfWeatherEvents <- as.numeric(forcingLine1Split[1])
#numberOfWeatherEvents <- 329
#numberOfWeatherEvents <- 86 *2
weatherEventsStart <- as.numeric(forcingLine1Split[2])
weatherIntervals <- as.numeric(forcingLine1Split[3])
totalRows <-  numberOfWeatherEvents * weatherIntervals

#totalEnd2 <- 1392
#totalEnd1 <- 696

totalEnd2 <- numberOfWeatherEvents
totalEnd1 <- totalEnd2/2

numberOfDays <- floor(totalRows /24)
endDay <- startDay + numberOfDays
endDayJulian <- as.numeric(startDayJulian) + numberOfDays

startDayDate <- as.Date(startDayJulian, "%j")
startDay <- as.numeric(format(startDayDate, "%d"))

startDayJulianNumber <- as.numeric(startDayJulian) 
startDayLabel <- as.Date(startDayJulianNumber, "%j", origin=as.Date("2004/01/01"))
endDayLabel <-   as.Date(endDayJulian        , "%j", origin=as.Date("2004/01/01"))

endMonth <- months(endDayLabel, abbreviate = TRUE)

sqlStatement <- paste("select Kup, Kdown, Ldown, Lup, NET, QH, QE, QG , cast(Timecode as text) timecode,Flux_validity from Preston_data ","where year=2004 and Day_of_year >= ",startDayJulianNumber," and Day_of_year <= ",endDayJulian,sep="")



library(zoo)
library(chron)
options("scipen" = 10)
start <- 0
end <- 1

prdata_table <-sqldf(sqlStatement, dbname="/home/kerryn/Documents/Work/PrestonData/Preston_Data.sqlite3") 
#prFilename <- "/home/kerryn/Documents/Work/PrestonData/PRESTON CITIES 13092011-r.csv"
#prdata_table <- read.table(prFilename,header = TRUE, sep=",")
prdts <- format(as.Date(as.character(prdata_table$timecode), "%Y%j%H%M"), format="%m/%d/%y")
prtms <- times(paste(substring (prdata_table$timecode, 8,9), substring (prdata_table$timecode, 10,11), "00", sep=":"))
prdatestimes <- chron(dates = prdts, times = prtms)

#remove gap filled values
prdata_table$Flux_validity[prdata_table$Flux_validity == 1] <- NA
for (i in 1:length(prdata_table$Flux_validity)) 
{
    if (is.na(prdata_table$Flux_validity[i]) ) 
    {
	prdata_table$Kdown[i] <- NA
	prdata_table$Kdown[i] <- NA
	prdata_table$Kup[i] <- NA
	prdata_table$Ldown[i] <- NA
	prdata_table$Lup[i] <- NA
	prdata_table$NET[i] <- NA
	prdata_table$QH[i] <- NA
	prdata_table$QE[i] <- NA
	prdata_table$QG[i] <- NA
    }    
}

prkdown <- zoo(prdata_table$Kdown, prdatestimes )
prkup <- zoo(prdata_table$Kup, prdatestimes )
prldown <- zoo(prdata_table$Ldown, prdatestimes )
prlup <- zoo(prdata_table$Lup, prdatestimes )
prqn <- zoo(prdata_table$NET, prdatestimes )
prh_mod <- zoo(prdata_table$QH, prdatestimes )
pre_mod <- zoo(prdata_table$QE, prdatestimes )
prqs <- zoo(prdata_table$QG, prdatestimes )

totalRows <-  numberOfWeatherEvents * weatherIntervals + 1
rownum <- 1

#prqnh1 <- prqn[days(time(prqn)) %in% c(startDay:endDay) & (months(time(prqn)) %in% c(startMonth) || months(time(prqn)) %in% c(endMonth) ) & years(time(prqn)) %in% c("2004"),] 
prqnhagg1 <- aggregate(prqn, hours, mean, na.rm=TRUE) 
#prh_modh1 <- prh_mod[days(time(prh_mod)) %in% c(startDay:endDay) & (months(time(prh_mod)) %in% c(startMonth) || months(time(prh_mod)) %in% c(endMonth) ) & years(time(prh_mod)) %in% c("2004"),] 
prh_modhagg1 <- aggregate(prh_mod, hours, mean, na.rm=TRUE) 
#prqsh1 <- prqs[days(time(prqs)) %in% c(startDay:endDay) & (months(time(prqs)) %in% c(startMonth) || months(time(prqs)) %in% c(endMonth) ) & years(time(prqs)) %in% c("2004"),] 
prqshagg1 <- aggregate(prqs, hours, mean, na.rm=TRUE) 
#prkdownh1 <- prkdown[days(time(prkdown)) %in% c(startDay:endDay) & (months(time(prkdown)) %in% c(startMonth) || months(time(prkdown)) %in% c(endMonth) ) & years(time(prkdown)) %in% c("2004"),] 
prkdownhagg1 <- aggregate(prkdown, hours, mean, na.rm=TRUE) 
#pre_modh1 <- pre_mod[days(time(pre_mod)) %in% c(startDay:endDay) & (months(time(pre_mod)) %in% c(startMonth) || months(time(pre_mod)) %in% c(endMonth) ) & years(time(pre_mod)) %in% c("2004"),] 
pre_modhagg1 <- aggregate(pre_mod, hours, mean, na.rm=TRUE) 

plot_colors <- colorRampPalette(c('black','red','blue','orange','green'))(5) 
colnames <- c("lambdap","H/L","H/W","latitude","streetdir","julian_day","time_of_day","time(continuous)","Rnet_tot","Qh_SumSfc","Qh_Vol","Qg_SumSfc","Qg_SfcCanAir","Rnet_can","Qh_CanTop","Qh_SumCanSfc","Qg_Can_CanAir","Ucan","Utop","Uroad","wstar","Kdn","Kup","Ldn","Lup","Kdir_Calc","Kdif_Calc","Kdir","Kdif","Kup_can","Lup_can","az","zen","KdnNoAtm","Kdn_grid","Qe_tot")
filename <-"EnergyBalance_Overall.out"


index<-0
startRow <- (index * totalRows) + rownum

outputString <-  paste("startRow=",startRow,sep="")
write(outputString, stderr())


filename <-"EnergyBalance_Overall.out"
data_table <- readTableFromZip(filename,header = FALSE, skip=startRow,col.names=colnames, nrows=totalRows)
#dts <-format(as.Date(data_table$julian_day, origin="2003-12-31"), format="%m/%d/%y")
dts <-format(as.Date(data_table$julian_day, origin="2004-01-01"), format="%m/%d/%y")
tms <-times(data_table$time_of_day/24 )
datestimes <- chron(dates = dts, times = tms)

Kup <- zoo(data_table$Kup, datestimes)
Rnet_tot  <- zoo(data_table$Rnet_tot, datestimes)
Qh_SumSfc  <- zoo(data_table$Qh_SumSfc, datestimes)
Qh_Vol  <- zoo(data_table$Qh_Vol, datestimes)
Qg_SumSfc  <- zoo(data_table$Qg_SumSfc, datestimes)
Qg_SfcCanAir  <- zoo(data_table$Qg_SfcCanAir, datestimes)
Rnet_can  <- zoo(data_table$Rnet_can, datestimes)
Qh_CanTop  <- zoo(data_table$Qh_CanTop, datestimes)
Qh_SumCanSfc  <- zoo(data_table$Qh_SumCanSfc, datestimes)
Qg_Can_CanAir  <- zoo(data_table$Qg_Can_CanAir, datestimes)

Qe_tot <- zoo(data_table$Qe_tot,datestimes)


Kdn  <- zoo(data_table$Kdn, datestimes)
Kup  <- zoo(data_table$Kup, datestimes)
Ldn  <- zoo(data_table$Ldn, datestimes)
Lup  <- zoo(data_table$Lup, datestimes)
Kdir  <- zoo(data_table$Kdir, datestimes)
Kdif  <- zoo(data_table$Kdif, datestimes)
Kup_can  <- zoo(data_table$Kup_can, datestimes)
Lup_can  <- zoo(data_table$Lup_can, datestimes)

require(hydroGOF)

#kdn
newprkdown <- prkdown[1:totalEnd2]
newprkdownHourly <- newprkdown[seq(1,length(newprkdown),2)]
newKdn <- Kdn[1:totalEnd1]
kdnRmse <- rmse(newprkdownHourly,newKdn )

#rnet
newprqn <- prqn[1:totalEnd2]
newprqnHourly <- newprqn[seq(1,length(newprqn),2)]
newRnet_tot <- Rnet_tot[1:totalEnd1]
rnetRmse <- rmse(newprqnHourly,newRnet_tot )
#qe
newpre_mod <- pre_mod[1:totalEnd2]
newpre_modHourly <- newpre_mod[seq(1,length(newpre_mod),2)]
newQe_tot <- Qe_tot[1:totalEnd1]
qeRmse <- rmse(newpre_modHourly,newQe_tot )
#qg
newprqs <- prqs[1:totalEnd2]
newprqsHourly <- newprqs[seq(1,length(newprqs),2)]
newQg_SfcCanAir <- Qg_SfcCanAir[1:totalEnd1]
qgRmse <- rmse(newprqsHourly,newQg_SfcCanAir )
#qh
newprh_mod <- prh_mod[1:totalEnd2]
newprh_modHourly <- newprh_mod[seq(1,length(newprh_mod),2)]
newQh_Vol <- Qh_Vol[1:totalEnd1]
qhRmse <- rmse(newprh_modHourly,newQh_Vol )

rnetLabel <- paste("Rnet ",round(rnetRmse, digits = 3),sep="")
QhLabel <-   paste("Qh ",  round(qeRmse, digits = 3),sep="")
QgLabel <-   paste("Qg ",  round(qgRmse, digits = 3),sep="")
KdnLabel <-  paste("Kdn ", round(kdnRmse, digits = 3),sep="")
QeLabel <-   paste("Qe ",  round(qhRmse, digits = 3),sep="")

Rnet_toth1 <- Rnet_tot[days(time(Rnet_tot)) %in% c(startDay:endDay) & (months(time(Rnet_tot)) %in% c(startMonth) || months(time(Rnet_tot)) %in% c(endMonth)) & years(time(Rnet_tot)) %in% c("2004"),] 
Rnet_tothagg1 <- aggregate(Rnet_toth1, hours, mean, na.rm=TRUE) 
Qh_Volh1 <- Qh_Vol[days(time(Qh_Vol)) %in% c(startDay:endDay) & (months(time(Qh_Vol)) %in% c(startMonth) || months(time(Qh_Vol)) %in% c(endMonth)) & years(time(Qh_Vol)) %in% c("2004"),] 
Qh_Volhagg1 <- aggregate(Qh_Volh1, hours, mean, na.rm=TRUE) 
Qg_SfcCanAirh1 <- Qg_SfcCanAir[days(time(Qg_SfcCanAir)) %in% c(startDay:endDay) & (months(time(Qg_SfcCanAir)) %in% c(startMonth) || months(time(Qg_SfcCanAir)) %in% c(endMonth)) & years(time(Qg_SfcCanAir)) %in% c("2004"),] 
Qg_SfcCanAirhagg1 <- aggregate(Qg_SfcCanAirh1, hours, mean, na.rm=TRUE) 
Kdnh1 <- Kdn[days(time(Kdn)) %in% c(startDay:endDay) & (months(time(Kdn)) %in% c(startMonth) || months(time(Kdn)) %in% c(endMonth)) & years(time(Kdn)) %in% c("2004"),] 
Kdnhagg1 <- aggregate(Kdnh1, hours, mean, na.rm=TRUE) 

Qeh1 <- Qe_tot[days(time(Qe_tot)) %in% c(startDay:endDay) & (months(time(Qe_tot)) %in% c(startMonth) || months(time(Qe_tot)) %in% c(endMonth)) & years(time(Qe_tot)) %in% c("2004"),] 
Qehagg1 <- aggregate(Qeh1, hours, mean, na.rm=TRUE) 

imageName <- paste("EnergyBalanceOverallAve_",".png",sep="")

png(imageName[1], width = 1536, height = 900)

label <- paste("VTUF-3D fluxes (hourly ave) days ",startDayLabel," to ", endDayLabel,sep="")

#y_range <- range(-400, 1000)
y_range <- range(Rnet_tothagg1,prqnhagg1,Qh_Volhagg1,prh_modhagg1,Qg_SfcCanAirhagg1,prqshagg1,Kdnhagg1,prkdownhagg1,Qehagg1,pre_modhagg1) 

plot(Rnet_tothagg1, type="b", xlab="Time of day", ylab="w/m2", lwd=2, pch=1, lty=2, col=plot_colors[1],ylim=y_range)
lines(prqnhagg1 , type="b", lwd=2, pch=1, lty=1, col=plot_colors[1])
lines(Qh_Volhagg1 , type="b", lwd=2, pch=2, lty=2, col=plot_colors[2])
lines(prh_modhagg1 , type="b", lwd=2, pch=2, lty=1, col=plot_colors[2])
lines(Qg_SfcCanAirhagg1 , type="b", lwd=2, pch=3, lty=2, col=plot_colors[3])
lines(prqshagg1 , type="b", lwd=2, pch=3, lty=1, col=plot_colors[3])
lines(Kdnhagg1 , type="b", lwd=2, pch=4, lty=2, col=plot_colors[4])
lines(prkdownhagg1 , type="b", lwd=2, pch=4, lty=1, col=plot_colors[4])

lines(Qehagg1 , type="b", lwd=2, pch=5, lty=2, col=plot_colors[5])
lines(pre_modhagg1 , type="b", lwd=2, pch=5, lty=1, col=plot_colors[5])
abline(h=0)

legend("topright", legend = c(rnetLabel,QhLabel,QgLabel,KdnLabel,QeLabel), col = plot_colors[1:5], lty = 1:1, pch=1:5)

legend("topleft", legend = c("Preston observed","VTUF-3D modelled"), col = plot_colors[1:1], lty = 1:2, pch=1:1)
title(label[1], "")
box()
grid()

dev.off()


imageName <- paste("EnergyBalanceOverallAveDiff_",".png",sep="")

png(imageName[1], width = 1536, height = 900)

label <- paste("VTUF-3D fluxes (hourly ave) days differences (VTUF - Preston) ",startDayLabel," to ", endDayLabel,sep="")

#y_range <- range(-400, 1000)
y_range <- range(Rnet_tothagg1-prqnhagg1,Qh_Volhagg1-prh_modhagg1,Qg_SfcCanAirhagg1-prqshagg1,Kdnhagg1-prkdownhagg1,Qehagg1-pre_modhagg1) 

plot(Rnet_tothagg1-prqnhagg1, type="b", xlab="Time of day", ylab="w/m2", lwd=2, pch=1, lty=2, col=plot_colors[1],ylim=y_range)
lines(Qh_Volhagg1-prh_modhagg1 , type="b", lwd=2, pch=2, lty=2, col=plot_colors[2])
lines(Qg_SfcCanAirhagg1-prqshagg1 , type="b", lwd=2, pch=3, lty=2, col=plot_colors[3])
lines(Kdnhagg1-prkdownhagg1 , type="b", lwd=2, pch=4, lty=2, col=plot_colors[4])
lines(Qehagg1-pre_modhagg1 , type="b", lwd=2, pch=5, lty=2, col=plot_colors[5])
abline(h=0)

legend("topright", legend = c("Rnet","Qh","Qg","Kdn","Qe"), col = plot_colors[1:5], lty = 1:1, pch=1:5)
title(label[1], "")
box()
grid()

dev.off()


