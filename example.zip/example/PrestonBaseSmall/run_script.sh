matlab -nodesktop -nosplash -r "run Matlab_plot.m;exit"

