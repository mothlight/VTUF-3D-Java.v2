
clear

%Tbright_yd172_lp20_bhbl070_lat30N_stror00_tim1300.out
%%%%% change these variables
% julian day
yd='040'
% building plan area ratio (lambdap)
lp='31'
% building height to width ratio (H/L)
bhbl='150'
% latitude (degrees)
lat='38S'
% street orientation, clockwise rotation from N-S-E-W alignment (degrees)
stror='00'
% hour of the day (local mean solar time)
tim='1200'
% variable to plot: Tsfc = surface temperature; Tbright ~= brightness temperature;
% Krefl = reflected solar (after multiple reflections); Kabs = absorbed solar (after multiple reflections)
var='Tsfc'
%%%%%
dir='./'
		
vert2=strcat(dir,'lp',lp,'_bhbl',bhbl,'_vertices_toMatlab.out')
face2=strcat(dir,'lp',lp,'_bhbl',bhbl,'_faces_toMatlab.out')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');

vert=load(vert2);
face=load(face2);
toplot=load(toplot2);

colormap(jet)
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label


axis([12.0,15.0,12.0,15.0])

%set(gca,'YDir','reverse');
axis ij

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='0000'
image=strcat(var,'_', '2004-02-09-0000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-0000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([12.0,15.0,12.0,15.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='0100'
image=strcat(var,'_', '2004-02-09-0100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-0100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([12.0,15.0,12.0,15.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='0200'
image=strcat(var,'_', '2004-02-09-0200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-0200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([12.0,15.0,12.0,15.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='0300'
image=strcat(var,'_', '2004-02-09-0300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-0300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([12.0,15.0,12.0,15.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='0400'
image=strcat(var,'_', '2004-02-09-0400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-0400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([12.0,15.0,12.0,15.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='0500'
image=strcat(var,'_', '2004-02-09-0500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-0500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([12.0,15.0,12.0,15.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='0600'
image=strcat(var,'_', '2004-02-09-0600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-0600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([12.0,15.0,12.0,15.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='0700'
image=strcat(var,'_', '2004-02-09-0700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-0700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([12.0,15.0,12.0,15.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='0800'
image=strcat(var,'_', '2004-02-09-0800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-0800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([12.0,15.0,12.0,15.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='0900'
image=strcat(var,'_', '2004-02-09-0900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-0900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([12.0,15.0,12.0,15.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='1000'
image=strcat(var,'_', '2004-02-09-1000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-1000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([12.0,15.0,12.0,15.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='1100'
image=strcat(var,'_', '2004-02-09-1100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-1100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([12.0,15.0,12.0,15.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='1200'
image=strcat(var,'_', '2004-02-09-1200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-1200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([12.0,15.0,12.0,15.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='1300'
image=strcat(var,'_', '2004-02-09-1300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-1300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([12.0,15.0,12.0,15.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='1400'
image=strcat(var,'_', '2004-02-09-1400' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-1400 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([12.0,15.0,12.0,15.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='1500'
image=strcat(var,'_', '2004-02-09-1500' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-1500 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([12.0,15.0,12.0,15.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='1600'
image=strcat(var,'_', '2004-02-09-1600' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-1600 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([12.0,15.0,12.0,15.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='1700'
image=strcat(var,'_', '2004-02-09-1700' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-1700 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([12.0,15.0,12.0,15.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='1800'
image=strcat(var,'_', '2004-02-09-1800' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-1800 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([12.0,15.0,12.0,15.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='1900'
image=strcat(var,'_', '2004-02-09-1900' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-1900 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([12.0,15.0,12.0,15.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='2000'
image=strcat(var,'_', '2004-02-09-2000' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-2000 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([12.0,15.0,12.0,15.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='2100'
image=strcat(var,'_', '2004-02-09-2100' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-2100 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([12.0,15.0,12.0,15.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='2200'
image=strcat(var,'_', '2004-02-09-2200' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-2200 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([12.0,15.0,12.0,15.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var='Tsfc'
tim='2300'
image=strcat(var,'_', '2004-02-09-2300' ,'.jpg')
imageName=strcat(var,' at ', ' 2004-02-09-2300 ')
toplot2=strcat(dir,'toMatlab_',var,'_yd',yd,'_lp',lp,'_bhbl',bhbl,'_lat',lat,'_stror',stror,'_tim',tim,'.out');
toplot=load(toplot2);
patch('Vertices',vert,'Faces',face,'CData',toplot,'FaceColor','flat')
title(imageName);
hgexport(gcf, image, hgexport('factorystyle'), 'Format', 'jpeg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear toplot
axis([12.0,15.0,12.0,15.0])
colormap(jet)
c=colorbar
c.Label.String = 'degrees C';
xlabel('x (5.0m grids)'); % x-axis label
ylabel('y (5.0m grids)'); % y-axis label
axis ij

