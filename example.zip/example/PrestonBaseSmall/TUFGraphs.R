library(zoo) 
library(chron) 
library(RColorBrewer) 
library(sqldf) 

start <- 0 
end <- 0
 
yearOffset <- 365*0
prdata_table <-sqldf("select Kup, Kdown, Ldown, Lup, NET, QH, QE, QG , cast(Timecode as text) timecode from Preston_data ", dbname="/home/kerryn/Documents/Work/PrestonData/Preston_Data.sqlite3") 
prdts <- format(as.Date(as.character(prdata_table$timecode), "%Y%j%H%M") + yearOffset, format="%m/%d/%y") 
prtms <- times(paste(substring (prdata_table$timecode, 8,9), substring (prdata_table$timecode, 10,11), "00", sep=":")) 
prdatestimes <- chron(dates = prdts, times = prtms) 

prkdown <- zoo(prdata_table$Kdown, prdatestimes ) 
prkup <- zoo(prdata_table$Kup, prdatestimes ) 
prldown <- zoo(prdata_table$Ldown, prdatestimes ) 
prlup <- zoo(prdata_table$Lup, prdatestimes ) 
prqn <- zoo(prdata_table$NET, prdatestimes ) 
prh_mod <- zoo(prdata_table$QH, prdatestimes ) 
pre_mod <- zoo(prdata_table$QE, prdatestimes ) 
prqs <- zoo(prdata_table$QG, prdatestimes ) 

totalRows <- 24 
rownum <- 1 

plot_colors <- colorRampPalette(c('red','green','orange','blue','yellow'))(21) 
colnames <- c("lambdap","H/L","H/W","latitude","streetdir","julian_day","time_of_day","time(continuous)","Rnet_tot","Qh_SumSfc","Qh_Vol","Qg_SumSfc","Qg_SfcCanAir","Rnet_can","Qh_CanTop","Qh_SumCanSfc","Qg_Can_CanAir","Ucan","Utop","Uroad","wstar","Kdn","Kup","Ldn","Lup","Kdir_Calc","Kdif_Calc","Kdir","Kdif","Kup_can","Lup_can","az","zen","Kdn(NoAtm)","Kdn_grid","Qe_tot") 
filename <-"EnergyBalance_Overall.out" 
 
plot_colorsFacets <- colorRampPalette(c('red','green','orange','blue','yellow'))(3) 
facetsColnames <- c("lambdap","H/L","H/W","latitude","streetdir","julian_day","time_of_day","time(continuous)","QR","HR","GR","QT","HT","GT","QN","HN","GN","QS","HS","GS","QE","HE","GE","QW","HW","GW") 
facetsFilename <-"EnergyBalance_Facets.out" 
 
enBaTsfcTmAvColnames <- c("lambdap","H/L","H/W","latitude","streetdir","julian_day","time_of_day(centre)","time(continuous&centre)","time_of_day(end)","time(continuous&end)","Kuptot_avg","Luptot_avg","Rntot_avg","Qhtot_avg","Qgtot_avg","Qanthro_avg","Qac_avg","Qdeep_avg","Qtau","TR_avg","TT_avg","TN_avg","TS_avg","TE_avg","TW_avg") 
enBaTsfcTmAvFilename <- "EnergyBalance_Tsfc_TimeAverage.out" 
 
enBaTsfcTmAvColnames <- c("lambdap","H/L","H/W","latitude","streetdir","julian_day","time_of_day(centre)","time(continuous&centre)","time_of_day(end)","time(continuous&end)","Kuptot_avg","Luptot_avg","Rntot_avg","Qhtot_avg","Qgtot_avg","Qanthro_avg","Qac_avg","Qdeep_avg","Qtau","TR_avg","TT_avg","TN_avg","TS_avg","TE_avg","TW_avg") 
enBaTsfcTmAvFilename <- "EnergyBalance_Tsfc_TimeAverage.out" 
 
tscf_facetsColnames <- c("lambdap","H/L","H/W","latitude","streetdir","julian_day","time_of_day","time(continuous)","Tcomplete","Tbirdeye","Troof","Troad","Tnorth","Tsouth","Teast","Twest","Tcan","Ta","Tint","httcR","httcT","httcW","TbrightR","TbrightT","TbrightN","TbrightS","TbrightE","TbrightW") 
tscf_facetsFilename <- "Tsfc_Facets.out" 
 
radiationBalanceFacColnames <- c("lambdap","H/L","H/W","latitude","streetdir","julian_day","time_of_day","time(continuous)","SKd","SKup","SLd","SLup","EKd","EKup","ELd","ELup","NKd","NKup","NLd","NLup","WKd","WKup","WLd","WLup","RfKd","RfKup","RfLd","RfLup","FKd","FKup","FLd","FLup") 
radiationBalanceFacFilename <- "RadiationBalance_Facets.out" 
 
tscfSunshadeColnames <- c("lambdap","H/L","H/W","latitude","streetdir","julian_day","time_of_day","time(continuous)","TTsun","TTsh","TNsun","TNsh","TSsun","TSsh","TEsun","TEsh","TWsun","TWsh") 
tscfSunshadeFilename <- "Tsfc_Facets_SunShade.out" 
 

readTableFromZip <- function(filename,header = FALSE, skip=startRow,col.names=colnames, nrows=totalRows) 
{
  if (  file.exists("out.zip") )
  {
    data_table <- read.table(unz("out.zip", filename),header = FALSE, skip=startRow,col.names=colnames, nrows=totalRows) 
  }
  else 
  {
      data_table <- read.table(filename,header = FALSE, skip=startRow,col.names=colnames, nrows=totalRows) 
  }
  
  return(data_table)
}

for (index in start:end) 
{ 
    startRow <- (index * totalRows) + rownum 
    
    data_table <- readTableFromZip(filename,header = FALSE, skip=startRow,col.names=colnames, nrows=totalRows) 
dts <-format(as.Date(data_table$julian_day, origin="2004-01-01"), format="%m/%d/%y") 
tms <-times(data_table$time_of_day/24 ) 
    datestimes <- chron(dates = dts, times = tms) 

Kup <- zoo(data_table$Kup, datestimes) 
Rnet_tot  <- zoo(data_table$Rnet_tot, datestimes) 
    Qh_SumSfc  <- zoo(data_table$Qh_SumSfc, datestimes) 
    Qh_Vol  <- zoo(data_table$Qh_Vol, datestimes) 
    Qg_SumSfc  <- zoo(data_table$Qg_SumSfc, datestimes) 
    Qg_SfcCanAir  <- zoo(data_table$Qg_SfcCanAir, datestimes) 
    Rnet_can  <- zoo(data_table$Rnet_can, datestimes) 
    Qh_CanTop  <- zoo(data_table$Qh_CanTop, datestimes) 
    Qh_SumCanSfc  <- zoo(data_table$Qh_SumCanSfc, datestimes) 
    Qg_Can_CanAir  <- zoo(data_table$Qg_Can_CanAir, datestimes) 
    Kdn  <- zoo(data_table$Kdn, datestimes) 
    Kup  <- zoo(data_table$Kup, datestimes) 
    Ldn  <- zoo(data_table$Ldn, datestimes) 
    Lup  <- zoo(data_table$Lup, datestimes) 
    Kdir  <- zoo(data_table$Kdir, datestimes) 
    Kdif  <- zoo(data_table$Kdif, datestimes) 
    Kup_can  <- zoo(data_table$Kup_can, datestimes) 
    Lup_can  <- zoo(data_table$Lup_can, datestimes) 
    Qe <- zoo(data_table$Qe_tot, datestimes)  



		    #plot_colors <- brewer.pal(n = 17, name = "Dark2") 
startDayLabel <- as.Date(data_table$julian_day[1], "%j", origin=as.Date("2004/01/01")) 
		    imageName <- paste("EnergyBalanceOverall1_",startDayLabel,".png",sep="")  

		    png(imageName[1], width = 1536, height = 900) 

		    label <- paste("VTUF-3D fluxes ",sep="") 

		    y_range <- range(Kup,Rnet_tot,Qh_Vol,Qg_SfcCanAir,Kdn,Kup,Ldn,Lup,Kdir,Kdif,Kup_can,Lup_can ) 

    plot(Kup, type="b", xlab="Time", ylab="w/m2", lwd=2, pch=1, lty=2, col=plot_colors[1],ylim=y_range) 
		    #lines(Kup , type="b", lwd=1, pch=2, lty=2, col=plot_colors[2]) 
		    lines(prkup , type="b", lwd=2, pch=1, lty=1, col=plot_colors[1])  #preston kup 
		    lines(prqn , type="b", lwd=2, pch=2, lty=1, col=plot_colors[2]) #preston net 
		    lines(prh_mod , type="b", lwd=2, pch=3, lty=1, col=plot_colors[3]) #preston qh 
		    lines(prqs , type="b", lwd=2, pch=4, lty=1, col=plot_colors[4]) #preston qg 
		    lines(prkdown , type="b", lwd=2, pch=6, lty=1, col=plot_colors[5])  #preston kdown 
		    lines(prldown , type="b", lwd=2, pch=6, lty=1, col=plot_colors[6]) #preston ldown 
		    lines(prlup , type="b", lwd=2, pch=7, lty=1, col=plot_colors[7]) #preston lup 
		    
		    lines(Rnet_tot , type="b", lwd=1, pch=2, lty=2, col=plot_colors[2]) 
		    lines(Qh_Vol , type="b", lwd=1, pch=3, lty=2, col=plot_colors[3]) #TUF Qh 
    #lines(Qg_SumSfc , type="b", lwd=1, pch=5, lty=2, col=plot_colors[4]) 

		    lines(Qg_SfcCanAir , type="b", lwd=1, pch=4, lty=2, col=plot_colors[4]) #TUF QG 
		    #lines(Qh_CanTop , type="b", lwd=1, pch=7, lty=2, col=plot_colors[7]) 
 
		    #lines(Qh_SumCanSfc , type="b", lwd=1, pch=8, lty=2, col=plot_colors[8]) 
 
		    #lines(Qg_Can_CanAir , type="b", lwd=1, pch=9, lty=2, col=plot_colors[9]) 
		     
		    lines(Kdn , type="b", lwd=1, pch=5, lty=2, col=plot_colors[5]) 
		    lines(Ldn , type="b", lwd=1, pch=6, lty=2, col=plot_colors[6]) 
		    lines(Lup , type="b", lwd=1, pch=7, lty=2, col=plot_colors[7]) 
		    lines(Kdir , type="b", lwd=1, pch=8, lty=2, col=plot_colors[8]) 
		    lines(Kdif , type="b", lwd=1, pch=9, lty=2, col=plot_colors[9]) 
		    lines(Kup_can , type="b", lwd=1, pch=10, lty=2, col=plot_colors[10]) 
		    lines(Lup_can , type="b", lwd=1, pch=11, lty=2, col=plot_colors[11]) 
 

		    legend("topright", legend = c("Kup", "Rnet_tot(Q*)","Qh_Vol(QH)","Qg_SfcCanAir","Kdn","Ldn","Lup","Kdir","Kdif","Kup_can","Lup_can"), col = plot_colors[1:11], lty = 1:1, pch=1:11) 
 
		    legend("topleft", legend = c("Preston","VTUF-3D"), col = plot_colors[1:1], lty = 1:2, pch=1:1) 
		    title(label[1], "") 
		    box() 
		    grid() 
 
		    dev.off() 
 


		   plot_colors_overall <- brewer.pal(n = 8, name = "Dark2") 
		  # plot_colors_overall <- colorRampPalette(c('red','green','orange','blue','yellow'))(9) 
		   startDayLabel <- as.Date(data_table$julian_day[1], "%j", origin=as.Date("2004/01/01")) 
		   imageName <- paste("EnergyBalanceOverall2_",startDayLabel,".png",sep="") 
 
		    png(imageName[1], width = 1536, height = 900) 

		    label <- paste("VTUF-3D fluxes",sep="") 
 
		    y_range <- range(Kup,prkup,Rnet_tot,prqn,Qh_Vol,prh_mod,Qg_SfcCanAir,prqs,Qe,pre_mod,Kdn,prkdown,Ldn,prldown,Lup,prlup )

		    plot(Kup, type="b", xlab="Time", ylab="w/m2", lwd=2, pch=1, lty=1, col=plot_colors_overall[1],ylim=y_range) #TUF kup  
		    #lines(Kup , type="b", lwd=1, pch=2, lty=2, col=plot_colors_overall[1]) #TUF kup 
		    lines(prkup , type="b", lwd=2, pch=1, lty=1, col=plot_colors_overall[1])  #preston kup 
		    lines(prqn , type="b", lwd=2, pch=2, lty=1, col=plot_colors_overall[2]) #preston net 
		    lines(prh_mod , type="b", lwd=2, pch=3, lty=1, col=plot_colors_overall[3]) #preston qh 
		    lines(prqs , type="b", lwd=2, cex=1.0, pch=4, lty=1, col=plot_colors_overall[4]) #preston qg 
		    lines(pre_mod , type="b", lwd=2, pch=5, lty=1, col=plot_colors_overall[5])  # preston qe 
		    lines(prkdown , type="b", lwd=2, pch=6, lty=1, col=plot_colors_overall[6])  #preston kdown 
		    lines(prldown , type="b", lwd=2, pch=7, lty=1, col=plot_colors_overall[7]) #preston ldown 
		    lines(prlup , type="b", lwd=2, pch=8, lty=2, col=plot_colors_overall[8]) #preston lup 
		    
		    lines(Rnet_tot , type="b", lwd=1, pch=2, lty=2, col=plot_colors_overall[2]) #TUF Rnet 
		    lines(Qh_Vol , type="b", lwd=1, pch=3, lty=2, col=plot_colors_overall[3]) #TUF qh 
		    #lines(Qg_SumSfc , type="b", lwd=1, pch=5, lty=2, col=plot_colors_overall[4]) 
 
		    lines(Qg_SfcCanAir , type="b", lwd=1, pch=4, lty=2, col=plot_colors_overall[4]) #TUF qg 
		    lines(Qe , type="b", lwd=1, pch=5, lty=2, col=plot_colors_overall[5]) #TUF qe 
		    #lines(Qh_CanTop , type="b", lwd=1, pch=7, lty=2, col=plot_colors[7]) 
		    #lines(Qh_SumCanSfc , type="b", lwd=1, pch=8, lty=2, col=plot_colors[8]) 
		    #lines(Qg_Can_CanAir , type="b", lwd=1, pch=9, lty=2, col=plot_colors[9]) 
 
		    lines(Kdn , type="b", lwd=1, pch=6, lty=2, col=plot_colors_overall[6]) 
		    lines(Ldn , type="b", lwd=1, pch=7, lty=2, col=plot_colors_overall[7]) 
		    lines(Lup , type="b", lwd=1, pch=8, lty=2, col=plot_colors_overall[8]) 
		    #lines(Kdir , type="b", lwd=1, pch=13, lty=2, col=plot_colors[13]) 
		    #lines(Kdif , type="b", lwd=1, pch=14, lty=2, col=plot_colors[14]) 
		    #lines(Kup_can , type="b", lwd=1, pch=15, lty=2, col=plot_colors[15]) 
		    #lines(Lup_can , type="b", lwd=1, pch=16, lty=2, col=plot_colors[16]) 
		     
		    legend("topright", legend = c("Kup", "Rnet","Qh","Qg","Qe","Kdn","Ldn","Lup"), col = plot_colors_overall[1:8], lty = 1:1, pch=1:8, cex=1.5) 
 
		    legend("topleft", legend = c("Preston","VTUF-3D"), col = plot_colors_overall[1:1], lty = 1:2, pch=1:1, cex=1.5) 
		    title(label[1], "") 
		    box() 
		    grid() 

		    dev.off() 

 


		   #plot_colors_overall <- brewer.pal(n = 9, name = "Spectral") 
		  # plot_colors_overall <- colorRampPalette(c('red','green','orange','blue','yellow'))(9) 
startDayLabel <- as.Date(data_table$julian_day[1], "%j", origin=as.Date("2004/01/01")) 
		   imageName <- paste("EnergyBalanceOverallSimple_",startDayLabel,".png",sep="")
 
		    png(imageName[1], width = 1536, height = 900) 

		    label <- paste("VTUF-3D fluxes",sep="")
 
		    y_range <- range(Kdn,prkdown,Rnet_tot,prqn,Qh_Vol,prh_mod,Qg_SfcCanAir,prqs,Qe,pre_mod )  

		    plot(Kdn, type="b", xlab="Time", ylab="w/m2", lwd=2, pch=1, lty=1, col=plot_colors_overall[1],ylim=y_range) 
		    lines(prkdown , type="b", lwd=2, pch=1, lty=1, col=plot_colors_overall[1])  #preston kup 
		    lines(prqn , type="b", lwd=2, pch=2, lty=1, col=plot_colors_overall[2]) #preston net 
		    lines(prh_mod , type="b", lwd=2, pch=3, lty=1, col=plot_colors_overall[3]) #preston qh 
		    lines(prqs , type="b", lwd=2, cex=1.0, pch=4, lty=1, col=plot_colors_overall[4]) #preston qg 
		    lines(pre_mod , type="b", lwd=2, pch=5, lty=1, col=plot_colors_overall[5])  # preston qe 
		    
		    #lines(Kdn , type="b", lwd=2, pch=1, lty=2, col=plot_colors_overall[1]) #TUF kup 
		    lines(Rnet_tot , type="b", lwd=2, pch=2, lty=2, col=plot_colors_overall[2]) #TUF Rnet 
		    lines(Qh_Vol , type="b", lwd=2, pch=3, lty=2, col=plot_colors_overall[3]) #TUF qh 
		    lines(Qg_SfcCanAir , type="b", lwd=2, pch=4, lty=2, col=plot_colors_overall[4]) #TUF qg 
		    lines(Qe , type="b", lwd=2, pch=5, lty=2, col=plot_colors_overall[5]) #TUF qe 
		    legend("topright", legend = c("Kdown", "Rnet","Qh","Qg","Qe"), col = plot_colors_overall[1:6], lty = 1:1, pch=1:5, cex=1.5) 
 
		    legend("topleft", legend = c("Preston","VTUF-3D"), col = plot_colors_overall[1:1], lty = 1:2, pch=1:1, cex=1.5) 
		    title(label[1], "") 
		    box() 
		    grid() 

		    dev.off() 

 
 
		    facetsdata_table <- readTableFromZip(facetsFilename,header = FALSE, skip=startRow,col.names=facetsColnames, nrows=totalRows) 
		    facetsdts <-format(as.Date(facetsdata_table$julian_day, origin="2004-01-01"), format="%m/%d/%y")    
		    facetstms <-times(facetsdata_table$time_of_day/24 )     
		    facetsdatestimes <- chron(dates = facetsdts, times = facetstms) 

		    facetsQR <- zoo(facetsdata_table$QR, facetsdatestimes) 
		    facetsHR  <- zoo(facetsdata_table$HR, facetsdatestimes) 
		    facetsGR  <- zoo(facetsdata_table$GR, facetsdatestimes) 
 
		    facetsQT <- zoo(facetsdata_table$QT, facetsdatestimes) 
		    facetsHT  <- zoo(facetsdata_table$HT, facetsdatestimes) 
		    facetsGT  <- zoo(facetsdata_table$GT, facetsdatestimes) 
 
		    facetsQN <- zoo(facetsdata_table$QN, facetsdatestimes) 
		    facetsHN  <- zoo(facetsdata_table$HN, facetsdatestimes) 
		    facetsGN  <- zoo(facetsdata_table$GN, facetsdatestimes) 
 
		    facetsQS <- zoo(facetsdata_table$QS, facetsdatestimes) 
		    facetsHS  <- zoo(facetsdata_table$HS, facetsdatestimes) 
		    facetsGS  <- zoo(facetsdata_table$GS, facetsdatestimes) 
 
		    facetsQE <- zoo(facetsdata_table$QE, facetsdatestimes) 
		    facetsHE  <- zoo(facetsdata_table$HE, facetsdatestimes) 
		    facetsGE  <- zoo(facetsdata_table$GE, facetsdatestimes) 
 
		    facetsQW <- zoo(facetsdata_table$QW, facetsdatestimes) 
		    facetsHW  <- zoo(facetsdata_table$HW, facetsdatestimes) 
		    facetsGW  <- zoo(facetsdata_table$GW, facetsdatestimes) 
 
 startDayLabel <- as.Date(facetsdata_table$julian_day[1], "%j", origin=as.Date("2004/01/01")) 
		    imageName <- paste("EnergyBalanceFacets_",startDayLabel,".png",sep="") 

		    png(imageName[1], width = 1536, height = 900) 

		    label <- paste("VTUF-3D facets fluxes",sep="")
 
		    y_range <- range(facetsQR,facetsHR,facetsGR,facetsQT,facetsHT,facetsGT,facetsQN,facetsHN,facetsGN,facetsQS,facetsHS,facetsGS,facetsQE,facetsHE,facetsGE,facetsQW,facetsHW,facetsGW) 

plot_colorsFacets <- colorRampPalette(c('black','red','blue','orange','green'))(5) 
		    plot(facetsQR, type="b", xlab="Time", ylab="w/m2", lwd=2, pch=1, lty=1, col=plot_colorsFacets[1],ylim=y_range) 
		    lines(facetsHR , type="b", lwd=1, pch=1, lty=2, col=plot_colorsFacets[2]) 
		    lines(facetsGR , type="b", lwd=1, pch=1, lty=1, col=plot_colorsFacets[3]) 
 
		    lines(facetsQT , type="b", lwd=1, pch=2, lty=2, col=plot_colorsFacets[1]) 
		    lines(facetsHT , type="b", lwd=1, pch=2, lty=1, col=plot_colorsFacets[2]) 
		    lines(facetsGT , type="b", lwd=1, pch=2, lty=1, col=plot_colorsFacets[3]) 
 
		    lines(facetsQN , type="b", lwd=1, pch=3, lty=2, col=plot_colorsFacets[1]) 
		    lines(facetsHN , type="b", lwd=1, pch=3, lty=1, col=plot_colorsFacets[2]) 
		    lines(facetsGN , type="b", lwd=1, pch=3, lty=1, col=plot_colorsFacets[3]) 

		    lines(facetsQS , type="b", lwd=1, pch=4, lty=2, col=plot_colorsFacets[1]) 
		    lines(facetsHS , type="b", lwd=1, pch=4, lty=1, col=plot_colorsFacets[2]) 
		    lines(facetsGS , type="b", lwd=1, pch=4, lty=1, col=plot_colorsFacets[3]) 

		    lines(facetsQE , type="b", lwd=1, pch=5, lty=2, col=plot_colorsFacets[1]) 
		    lines(facetsHE , type="b", lwd=1, pch=5, lty=1, col=plot_colorsFacets[2]) 
		    lines(facetsGE , type="b", lwd=1, pch=5, lty=1, col=plot_colorsFacets[3]) 
 
		    lines(facetsQW , type="b", lwd=1, pch=6, lty=2, col=plot_colorsFacets[1]) 
		    lines(facetsHW , type="b", lwd=1, pch=6, lty=1, col=plot_colorsFacets[2]) 
		    lines(facetsGW , type="b", lwd=1, pch=6, lty=1, col=plot_colorsFacets[3]) 
		     
		    legend("topright", legend = c("R","T","N","S","E","W"), col = plot_colorsFacets[1:1], lty = 1:1, pch=1:6) 
		    legend("topleft", legend = c("Q","H","G"), col = plot_colorsFacets[1:3], lty = 1:1, pch=1:1) 
		    
		    title(label[1], "") 
		    box() 
		    grid() 

		    dev.off() 
		    
 

		    enBaTsfcTmAvdata_table <- readTableFromZip(enBaTsfcTmAvFilename,header = FALSE, skip=startRow,col.names=enBaTsfcTmAvColnames, nrows=totalRows) 
		    enBaTsfcTmAvdata_table[enBaTsfcTmAvdata_table == '********'] <- NA
		    enBaTsfcTmAvdts <-format(as.Date(enBaTsfcTmAvdata_table$julian_day, origin="2004-01-01"), format="%m/%d/%y")    
		    enBaTsfcTmAvtms <-times( (enBaTsfcTmAvdata_table$time_of_day.centre. + enBaTsfcTmAvdata_table$time_of_day.end.)/2  /24 )   
		    enBaTsfcTmAvdatestimes <- chron(dates = enBaTsfcTmAvdts, times = enBaTsfcTmAvtms) 

		    Kuptot_avg <- na.omit(zoo(enBaTsfcTmAvdata_table$Kuptot_avg, enBaTsfcTmAvdatestimes)) 
		    Luptot_avg  <- na.omit(zoo(enBaTsfcTmAvdata_table$Luptot_avg, enBaTsfcTmAvdatestimes)) 
		    Rntot_avg  <- na.omit(zoo(enBaTsfcTmAvdata_table$Rntot_avg, enBaTsfcTmAvdatestimes)) 

		    Qhtot_avg <- na.omit(zoo(enBaTsfcTmAvdata_table$Qhtot_avg, enBaTsfcTmAvdatestimes)) 
		    Qgtot_avg  <- na.omit(zoo(enBaTsfcTmAvdata_table$Qgtot_avg, enBaTsfcTmAvdatestimes)) 
		    Qanthro_avg  <- na.omit(zoo(enBaTsfcTmAvdata_table$Qanthro_avg, enBaTsfcTmAvdatestimes)) 

		    Qac_avg <- na.omit(zoo(enBaTsfcTmAvdata_table$Qac_avg, enBaTsfcTmAvdatestimes)) 
		    Qdeep_avg  <- na.omit(zoo(enBaTsfcTmAvdata_table$Qdeep_avg, enBaTsfcTmAvdatestimes)) 
		    Qtau  <- na.omit(zoo(enBaTsfcTmAvdata_table$Qtau, enBaTsfcTmAvdatestimes)) 
 
		    TR_avg <- na.omit(zoo(enBaTsfcTmAvdata_table$TR_avg, enBaTsfcTmAvdatestimes)) 
		    TT_avg  <- na.omit(zoo(enBaTsfcTmAvdata_table$TT_avg, enBaTsfcTmAvdatestimes)) 
		    TN_avg  <- na.omit(zoo(enBaTsfcTmAvdata_table$TN_avg, enBaTsfcTmAvdatestimes)) 
 
		    TS_avg <- na.omit(zoo(enBaTsfcTmAvdata_table$TS_avg, enBaTsfcTmAvdatestimes)) 
		    TE_avg  <- na.omit(zoo(enBaTsfcTmAvdata_table$TE_avg, enBaTsfcTmAvdatestimes)) 
		    TW_avg  <- na.omit(zoo(enBaTsfcTmAvdata_table$TW_avg, enBaTsfcTmAvdatestimes)) 
 
startDayLabel <- as.Date(enBaTsfcTmAvdata_table$julian_day[1], "%j", origin=as.Date("2004/01/01")) 
		    imageName <- paste("EnergyBalanceenBaTmAv_",startDayLabel,".png",sep="") 
		    png(imageName[1], width = 1536, height = 900) 
 
		    label <- paste("VTUF-3D hourly-averaged facet-average ",sep="") 
 
		    y1_range <- range(Kuptot_avg,Luptot_avg,Rntot_avg,Qhtot_avg,Qgtot_avg,Qanthro_avg,Qac_avg,Qdeep_avg,Qtau) 
 
		    plot(Kuptot_avg, type="b", xlab="", ylab="", lwd=1, pch=1, lty=1, col=plot_colors[1],ylim=y1_range) 
		    lines(Luptot_avg , type="b", lwd=1, pch=2, lty=1, col=plot_colors[2]) 
		    lines(Rntot_avg , type="b", lwd=1, pch=3, lty=1, col=plot_colors[3]) 
		    lines(Qhtot_avg , type="b", lwd=1, pch=4, lty=1, col=plot_colors[4]) 
		    lines(Qgtot_avg , type="b", lwd=1, pch=5, lty=1, col=plot_colors[5]) 
		    lines(Qanthro_avg , type="b", lwd=1, pch=6, lty=1, col=plot_colors[6]) 
		    lines(Qac_avg , type="b", lwd=1, pch=7, lty=1, col=plot_colors[7]) 
		    lines(Qdeep_avg , type="b", lwd=1, pch=8, lty=1, col=plot_colors[8]) 
		    lines(Qtau , type="b", lwd=1, pch=9, lty=1, col=plot_colors[9]) 
 

		    mtext("w/m2",            # Add second y-axis label 
		      side=2,                     # Add to left hand side of plot   
		      line=2,                     # Add to line 2 from the margin   
		      font=1)  

		    axis(2,                           # Add a second axis: 1=below, 2=left, 3=above and 4=right 
		    pretty(y1_range,10))         # Intervals for the second y-axis    
		    
		    
		    mtext("Time",            # Add second y-axis label 
		      side=1,                     # Add to right hand side of plot 
		      line=2,                     # Add to line 3 from the margin   
		      font=1)  
 
		    
		    legend("topright", legend = c("Kuptot_avg","Luptot_avg","Rntot_avg","Qhtot_avg","Qgtot_avg","Qanthro_avg","Qac_avg","Qdeep_avg","Qtau"), col = plot_colors[1:9], lty = 1:1, pch=1:9) 
		    
		    title(label[1], "") 
		    box() 
		    grid() 

		    dev.off() 
 
		  
 
 imageName <- paste("EnergyBalanceenBaTmAvTsfc_",startDayLabel,".png",sep="") 
 png(imageName[1], width = 1536, height = 900)  
 label <- paste("VTUF-3D hourly-averaged facet-average surface temperatures",sep="") 		   
 y2_range <- range(TR_avg,TT_avg,TN_avg,TS_avg,TE_avg,TW_avg)  
 plot(TR_avg, type="b",xlab="",yaxt="n",ylab="", lwd=1, pch=1, lty=2, col=plot_colors[1],ylim=y2_range) 
 lines(TT_avg , type="b", lwd=1, pch=2, lty=2, col=plot_colors[2]) 
 lines(TN_avg , type="b", lwd=1, pch=3, lty=2, col=plot_colors[3]) 
 lines(TS_avg , type="b", lwd=1, pch=4, lty=2, col=plot_colors[4]) 
 lines(TE_avg , type="b", lwd=1, pch=5, lty=2, col=plot_colors[5]) 
 lines(TW_avg , type="b", lwd=1, pch=6, lty=2, col=plot_colors[6]) 
 mtext("temp C",            # Add second y-axis label 
    side=2,                     # Add to left hand side of plot   
    line=2,                     # Add to line 2 from the margin   
   font=1)  
 axis(2,                           # Add a second axis: 1=below, 2=left, 3=above and 4=right 
 pretty(y2_range,10))         # Intervals for the second y-axis   		
 mtext("Time",            # Add second y-axis label 
    side=1,                     # Add to right hand side of plot 
   line=2,                     # Add to line 3 from the margin  
   font=1)  		    
 legend("topleft", legend = c("TR_avg","TT_avg","TN_avg","TS_avg","TE_avg","TW_avg"), col = plot_colors[1:7], lty = 2:2, pch=1:7) 		
 title(label[1], "") 
 box() 
 grid() 
 dev.off() 
 
		    plot_colors_overall2 <- brewer.pal(n = 12, name = "Paired")  
		    tscf_facetsdata_table <- readTableFromZip(tscf_facetsFilename,header = FALSE, skip=startRow,col.names=tscf_facetsColnames, nrows=totalRows) 
		    tscf_facetsdts <-format(as.Date(tscf_facetsdata_table$julian_day, origin="2004-01-01"), format="%m/%d/%y")    
		    tscf_facetstms <-times( (tscf_facetsdata_table$time_of_day)/24 )     
		    tscf_facetsdatestimes <- chron(dates = tscf_facetsdts, times = tscf_facetstms) 
 
		    Tcomplete <- zoo(tscf_facetsdata_table$Tcomplete, tscf_facetsdatestimes) 
		    Tbirdeye  <- zoo(tscf_facetsdata_table$Tbirdeye, tscf_facetsdatestimes) 
		    Troof <- zoo(tscf_facetsdata_table$Troof, tscf_facetsdatestimes) 
		    Troad <- zoo(tscf_facetsdata_table$Troad, tscf_facetsdatestimes) 
		    Tnorth <- zoo(tscf_facetsdata_table$Tnorth, tscf_facetsdatestimes) 
		    Tsouth <- zoo(tscf_facetsdata_table$Tsouth, tscf_facetsdatestimes) 
		    Teast <- zoo(tscf_facetsdata_table$Teast, tscf_facetsdatestimes) 
		    Twest <- zoo(tscf_facetsdata_table$Twest, tscf_facetsdatestimes) 
		    Tcan <- zoo(tscf_facetsdata_table$Tcan, tscf_facetsdatestimes) 
		    Ta <- zoo(tscf_facetsdata_table$Ta, tscf_facetsdatestimes) 
		    Tint <- zoo(tscf_facetsdata_table$Tint, tscf_facetsdatestimes) 
		    #httcR <- zoo(tscf_facetsdata_table$httcR, tscf_facetsdatestimes) 
		    #httcT <- zoo(tscf_facetsdata_table$httcT, tscf_facetsdatestimes) 
		    #httcW <- zoo(tscf_facetsdata_table$httcW, tscf_facetsdatestimes) 
		    #TbrightR <- zoo(tscf_facetsdata_table$TbrightR, tscf_facetsdatestimes) 
		    #TbrightT <- zoo(tscf_facetsdata_table$TbrightT, tscf_facetsdatestimes) 
		    #TbrightN <- zoo(tscf_facetsdata_table$TbrightN, tscf_facetsdatestimes) 
		    #TbrightS <- zoo(tscf_facetsdata_table$TbrightS, tscf_facetsdatestimes) 
		    #TbrightE <- zoo(tscf_facetsdata_table$TbrightE, tscf_facetsdatestimes) 
		    #TbrightW <- zoo(tscf_facetsdata_table$TbrightW, tscf_facetsdatestimes) 
 
startDayLabel <- as.Date(tscf_facetsdata_table$julian_day[1], "%j", origin=as.Date("2004/01/01"))
		    imageName <- paste("EnergyBalancetscf_facets_",startDayLabel,".png",sep="") 
		    png(imageName, width = 1536, height = 900) 
 
		    label <- paste("VTUF-3D Tsfc facets ",sep="")
 
		    y1_range <- range(Tcomplete,Tbirdeye,Troof,Troad,Tnorth,Tsouth,Teast,Twest,Tcan,Ta,Tint) 
 
		    plot(Tcomplete, type="b", xlab="", ylab="", lwd=1, pch=1, lty=1, col=plot_colors_overall2[1],ylim=y1_range) 
		    lines(Tbirdeye, type="b", lwd=1, pch=2, lty=1, col=plot_colors_overall2[2]) 
		    lines(Troof, type="b", lwd=1, pch=3, lty=1, col=plot_colors_overall2[3]) 
		    lines(Troad, type="b", lwd=1, pch=4, lty=1, col=plot_colors_overall2[4]) 
		    lines(Tnorth, type="b", lwd=1, pch=5, lty=1, col=plot_colors_overall2[5]) 
		    lines(Tsouth, type="b", lwd=1, pch=6, lty=1, col=plot_colors_overall2[6]) 
		    lines(Teast, type="b", lwd=1, pch=7, lty=1, col=plot_colors_overall2[7]) 
		    lines(Twest, type="b", lwd=1, pch=8, lty=1, col=plot_colors_overall2[8]) 
		    lines(Tcan, type="b", lwd=3, pch=9, lty=1, col=plot_colors_overall2[9]) 
		    lines(Ta, type="b", lwd=3, pch=10, lty=1, col=plot_colors_overall2[10]) 
		    lines(Tint, type="b", lwd=1, pch=11, lty=1, col=plot_colors_overall2[11]) 
		    #lines(TbrightR, type="b", lwd=1, pch=12, lty=1, col=plot_colors[12]) 
		    #lines(TbrightT, type="b", lwd=1, pch=13, lty=1, col=plot_colors[13]) 
		    #lines(TbrightN, type="b", lwd=1, pch=14, lty=1, col=plot_colors[14]) 
		    #lines(TbrightS, type="b", lwd=1, pch=15, lty=1, col=plot_colors[15]) 
		    #lines(TbrightE, type="b", lwd=1, pch=16, lty=1, col=plot_colors[16]) 
		    #lines(TbrightW, type="b", lwd=1, pch=17, lty=1, col=plot_colors[17]) 



		    axis(2,                           # Add a second axis: 1=below, 2=left, 3=above and 4=right 
		    pretty(y1_range,10))         # Intervals for the second y-axis    
		    
		    mtext("temp C",            # Add second y-axis label 
		      side=2,                     # Add to right hand side of plot  
		      line=2,                     # Add to line 3 from the margin   
		      font=1)                  
 
		    mtext("Time",            # Add second y-axis label 
		      side=1,                     # Add to right hand side of plot 
		      line=2,                     # Add to line 3 from the margin   
		      font=1)  

		    axis(1,                           # Add a second axis: 1=below, 2=left, 3=above and 4=right 
		    pretty(y2_range,10))         # Intervals for the second y-axis     
		    
		    legend("topright", legend = c("Tcomplete","Tbirdeye","Troof","Troad","Tnorth","Tsouth","Teast","Twest","Tcan","Ta","Tint"
#,"TbrightR","TbrightT","TbrightN","TbrightS","TbrightE","TbrightW"
), col = plot_colors_overall2[1:11], lty = 1:1, pch=1:11) 
		    
		    title(label, "") 
		    box() 
		    grid() 
 
		    dev.off() 
 
 
		    radiationBalanceFacdata_table <- readTableFromZip(radiationBalanceFacFilename,header = FALSE, skip=startRow,col.names=radiationBalanceFacColnames, nrows=totalRows) 
		    radiationBalanceFacdts <-format(as.Date(radiationBalanceFacdata_table$julian_day, origin="2004-01-01"), format="%m/%d/%y")    
		    radiationBalanceFactms <-times( (radiationBalanceFacdata_table$time_of_day)/24 )     
		    radiationBalanceFacdatestimes <- chron(dates = radiationBalanceFacdts, times = radiationBalanceFactms) 
 
		    SKd <- zoo(radiationBalanceFacdata_table$SKd, radiationBalanceFacdatestimes) 
		    SKup  <- zoo(radiationBalanceFacdata_table$SKup, radiationBalanceFacdatestimes) 
		    SLd <- zoo(radiationBalanceFacdata_table$SLd, radiationBalanceFacdatestimes) 
		    SLup <- zoo(radiationBalanceFacdata_table$SLup, radiationBalanceFacdatestimes) 
		    EKd <- zoo(radiationBalanceFacdata_table$EKd, radiationBalanceFacdatestimes) 
		    EKup <- zoo(radiationBalanceFacdata_table$EKup, radiationBalanceFacdatestimes) 
		    ELd <- zoo(radiationBalanceFacdata_table$ELd, radiationBalanceFacdatestimes) 
		    ELup <- zoo(radiationBalanceFacdata_table$ELup, radiationBalanceFacdatestimes) 
		    NKd <- zoo(radiationBalanceFacdata_table$NKd, radiationBalanceFacdatestimes) 
		    NKup <- zoo(radiationBalanceFacdata_table$NKup, radiationBalanceFacdatestimes) 
		    NLd <- zoo(radiationBalanceFacdata_table$NLd, radiationBalanceFacdatestimes) 
		    NLup <- zoo(radiationBalanceFacdata_table$NLup, radiationBalanceFacdatestimes) 
		    WKd <- zoo(radiationBalanceFacdata_table$WKd, radiationBalanceFacdatestimes) 
		    WKup <- zoo(radiationBalanceFacdata_table$WKup, radiationBalanceFacdatestimes) 
		    WLd <- zoo(radiationBalanceFacdata_table$WLd, radiationBalanceFacdatestimes) 
		    WLup <- zoo(radiationBalanceFacdata_table$WLup, radiationBalanceFacdatestimes) 
		    RfKd <- zoo(radiationBalanceFacdata_table$RfKd, radiationBalanceFacdatestimes) 
		    RfKup <- zoo(radiationBalanceFacdata_table$RfKup, radiationBalanceFacdatestimes) 
		    RfLd <- zoo(radiationBalanceFacdata_table$RfLd, radiationBalanceFacdatestimes) 
		    RfLup <- zoo(radiationBalanceFacdata_table$RfLup, radiationBalanceFacdatestimes) 
		    FKd <- zoo(radiationBalanceFacdata_table$FKd, radiationBalanceFacdatestimes) 
		    FKup <- zoo(radiationBalanceFacdata_table$FKup, radiationBalanceFacdatestimes) 
		    FLd <- zoo(radiationBalanceFacdata_table$FLd, radiationBalanceFacdatestimes) 
		    FLup <- zoo(radiationBalanceFacdata_table$FLup, radiationBalanceFacdatestimes) 
 
startDayLabel <- as.Date(radiationBalanceFacdata_table$julian_day[1], "%j", origin=as.Date("2004/01/01"))
		    imageName <- paste("EnergyBalanceradiationBalanceFac_",startDayLabel,".png",sep="")
		    png(imageName, width = 1536, height = 900) 
 
		    label <- paste("VTUF-3D radiation balance facets ",sep="") 
 
		    y1_range <- range(SKd,SKup,SLd,SLup,EKd,EKup,ELd,ELup,NKd,NKup,NLd,NLup,WKd,WKup,WLd,WLup,RfKd,RfKup,RfLd,RfLup,FKd,FKup,FLd,FLup) 
 
plot_radiationBalanceFacdata <- colorRampPalette(c('black','red','blue','green','orange'))(5)  
		    plot(SKd, type="b", xlab="", ylab="", lwd=1, pch=1, lty=1, col=plot_radiationBalanceFacdata[1],ylim=y1_range) 
		    lines(SKup, type="b", lwd=1, pch=1, lty=1, col=plot_radiationBalanceFacdata[2]) 
		    lines(SLd, type="b", lwd=1, pch=1, lty=1, col=plot_radiationBalanceFacdata[3]) 
		    lines(SLup, type="b", lwd=1, pch=1, lty=1, col=plot_radiationBalanceFacdata[4]) 
		    lines(EKd, type="b", lwd=1, pch=2, lty=1, col=plot_radiationBalanceFacdata[1]) 
		    lines(EKup, type="b", lwd=1, pch=2, lty=1, col=plot_radiationBalanceFacdata[2]) 
		    lines(ELd, type="b", lwd=1, pch=2, lty=1, col=plot_radiationBalanceFacdata[3]) 
		    lines(ELup, type="b", lwd=1, pch=2, lty=1, col=plot_radiationBalanceFacdata[4]) 
		    lines(NKd, type="b", lwd=1, pch=3, lty=1, col=plot_radiationBalanceFacdata[1]) 
		    lines(NKup, type="b", lwd=1, pch=3, lty=1, col=plot_radiationBalanceFacdata[2]) 
		    lines(NLd, type="b", lwd=1, pch=3, lty=1, col=plot_radiationBalanceFacdata[3]) 
		    lines(NLup, type="b", lwd=1, pch=3, lty=1, col=plot_radiationBalanceFacdata[4]) 
		    lines(WKd, type="b", lwd=1, pch=4, lty=1, col=plot_radiationBalanceFacdata[1]) 
		    lines(WKup, type="b", lwd=1, pch=4, lty=1, col=plot_radiationBalanceFacdata[2]) 
		    lines(WLd, type="b", lwd=1, pch=4, lty=1, col=plot_radiationBalanceFacdata[3]) 
		    lines(WLup, type="b", lwd=1, pch=4, lty=1, col=plot_radiationBalanceFacdata[4]) 
		    lines(RfKd, type="b", lwd=1, pch=5, lty=1, col=plot_radiationBalanceFacdata[1]) 
		    lines(RfKup, type="b", lwd=1, pch=5, lty=1, col=plot_radiationBalanceFacdata[2]) 
		    lines(RfLd, type="b", lwd=1, pch=5, lty=1, col=plot_radiationBalanceFacdata[3]) 
		    lines(RfLup, type="b", lwd=1, pch=5, lty=1, col=plot_radiationBalanceFacdata[4]) 
		    lines(FKd, type="b", lwd=1, pch=6, lty=1, col=plot_radiationBalanceFacdata[1]) 
		    lines(FKup, type="b", lwd=1, pch=6, lty=1, col=plot_radiationBalanceFacdata[2]) 
		    lines(FLd, type="b", lwd=1, pch=6, lty=1, col=plot_radiationBalanceFacdata[3]) 
		    lines(FLup, type="b", lwd=1, pch=6, lty=1, col=plot_radiationBalanceFacdata[4]) 
 
		    mtext("w/m2",            # Add second y-axis label 
		      side=2,                     # Add to left hand side of plot   
		      line=2,                     # Add to line 2 from the margin   
		      font=1)  

		    axis(2,                           # Add a second axis: 1=below, 2=left, 3=above and 4=right 
		    pretty(y1_range,10))         # Intervals for the second y-axis    
		    
		    mtext("Time",            # Add second y-axis label 
		      side=1,                     # Add to right hand side of plot 
		      line=2,                     # Add to line 3 from the margin   
		      font=1)  

		    axis(1,                           # Add a second axis: 1=below, 2=left, 3=above and 4=right 
		    pretty(y2_range,10))         # Intervals for the second y-axis     
		    
legend("topright", legend = c("Kd","Kup","Ld","Lup"), col = plot_radiationBalanceFacdata[1:5], lty = 1:1, pch=1:25) 
legend("topleft", legend = c("S","E","N","W","R","F"), col = plot_radiationBalanceFacdata[1:1], lty = 1:1, pch=1:7)  
 
		    title(label, "") 
		    box() 
		    grid() 
 
		    dev.off() 
 
 
		  tscfSunshadedata_table <- readTableFromZip(tscfSunshadeFilename,header = FALSE, skip=startRow,col.names=tscfSunshadeColnames, nrows=totalRows) 
		    tscfSunshadedts <-format(as.Date(tscfSunshadedata_table$julian_day, origin="2004-01-01"), format="%m/%d/%y")    
		    tscfSunshadetms <-times( (tscfSunshadedata_table$time_of_day)/24 )     
		    tscfSunshadedatestimes <- chron(dates = tscfSunshadedts, times = tscfSunshadetms) 
 
		    TTsun <- zoo(tscfSunshadedata_table$TTsun, tscfSunshadedatestimes) 
		    TTsh  <- zoo(tscfSunshadedata_table$TTsh, tscfSunshadedatestimes) 
		    TNsun <- zoo(tscfSunshadedata_table$TNsun, tscfSunshadedatestimes) 
		    TNsh <- zoo(tscfSunshadedata_table$TNsh, tscfSunshadedatestimes) 
		    TSsun <- zoo(tscfSunshadedata_table$TSsun, tscfSunshadedatestimes) 
		    TSsh <- zoo(tscfSunshadedata_table$TSsh, tscfSunshadedatestimes) 
		    TEsun <- zoo(tscfSunshadedata_table$TEsun, tscfSunshadedatestimes) 
		    TEsh <- zoo(tscfSunshadedata_table$TEsh, tscfSunshadedatestimes) 
		    TWsun <- zoo(tscfSunshadedata_table$TWsun, tscfSunshadedatestimes) 
		    TWsh <- zoo(tscfSunshadedata_table$TWsh, tscfSunshadedatestimes) 
 
TTsun[TTsun==-273.150] <- 0.0
TTsh[TTsh==-273.150] <- 0.0 
TNsun[TNsun==-273.150] <- 0.0 
TNsh[TNsh==-273.150] <- 0.0 
TSsun[TSsun==-273.150] <- 0.0 
TSsh[TSsh==-273.150] <- 0.0 
TEsun[TEsun==-273.150] <- 0.0 
TEsh[TEsh==-273.150] <- 0.0 
TWsun[TWsun==-273.150] <- 0.0 
TWsh[TWsh==-273.150] <- 0.0 
imageName <- paste("EnergyBalancetscfSunshade_",startDayLabel,".png",sep="") 
		    startDayLabel <- as.Date(tscfSunshadedata_table$julian_day[1], "%j", origin=as.Date("2004/01/01"))
		    png(imageName, width = 1536, height = 900) 

		    label <- paste("VTUF-3D Tsfc sunshade ",startDayLabel,sep="") 
 
		    y1_range <- range(TTsun,TTsh,TNsun,TNsh,TSsun,TSsh,TEsun,TEsh,TWsun,TWsh) 
 
		    plot(TTsun, type="b", xlab="", ylab="", lwd=1, pch=1, lty=1, col=plot_colors[1],ylim=y1_range) 
		    lines(TTsh, type="b", lwd=1, pch=2, lty=1, col=plot_colors[2]) 
		    lines(TNsun, type="b", lwd=1, pch=3, lty=1, col=plot_colors[3]) 
		    lines(TNsh, type="b", lwd=1, pch=4, lty=1, col=plot_colors[4]) 
		    lines(TSsun, type="b", lwd=1, pch=5, lty=1, col=plot_colors[5]) 
		    lines(TSsh, type="b", lwd=1, pch=6, lty=1, col=plot_colors[6]) 
		    lines(TEsun, type="b", lwd=1, pch=7, lty=1, col=plot_colors[7]) 
		    lines(TEsh, type="b", lwd=1, pch=8, lty=1, col=plot_colors[8]) 
		    lines(TWsun, type="b", lwd=1, pch=9, lty=1, col=plot_colors[9]) 
		    lines(TWsh, type="b", lwd=1, pch=10, lty=1, col=plot_colors[10]) 
 
		    mtext("degrees C",            # Add second y-axis label 
		      side=2,                     # Add to left hand side of plot 
		      line=2,                     # Add to line 2 from the margin   
		      font=1)  
 
		    axis(2,                           # Add a second axis: 1=below, 2=left, 3=above and 4=right 
		    pretty(y1_range,10))         # Intervals for the second y-axis    
		    
		    
		    mtext("Time",            # Add second y-axis label 
		      side=1,                     # Add to right hand side of plot 
		      line=2,                     # Add to line 3 from the margin   
		      font=1)  

		    axis(1,                           # Add a second axis: 1=below, 2=left, 3=above and 4=right 
		    pretty(y2_range,10))         # Intervals for the second y-axis     
		    
		    legend("topright", legend = c("TTsun","TTsh","TNsun","TNsh","TSsun","TSsh","TEsun","TEsh","TWsun","TWsh"), col = plot_colors[1:10], lty = 1:1, pch=1:10) 
		     
		    title(label, "") 
		    box() 
		    grid() 
 
		    dev.off() 
		  
		} 

