rm out.zip
rm fort.8*
rm *.out
cd ~/VTUF_Runs//home/kerryn/git/2018-03-MasterITProject/VTUF3DTesting/PrestonBaseSmall/
rm ./TUF3Dradiation
ln -s /nfs/home/kerryn/VTUF3DBuild/TUF3Dradiation
rm confile.dat
cp 1/1/confile.dat confile.dat
setenv LD_LIBRARY_PATH /nfs/home/kerryn/gcc-trunk/lib/../lib64
./TUF3Dradiation
zip out.zip *.out
rm *.out
zip out.zip fort.8*
rm fort.8*
module load python/2.7.5
python GenerateUTCIFiles.py
zip out.zip *.out
rm *.out

