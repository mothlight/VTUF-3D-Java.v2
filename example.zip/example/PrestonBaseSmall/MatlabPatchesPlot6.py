import zipfile
import os.path
def openFile(filename):
  if (  os.path.isfile("out.zip") ):
     z = zipfile.ZipFile("out.zip", "r")
     f = z.open(filename)     
  else:
    f = open(filename)  
  return f
		  

from matplotlib import pyplot as plt
from matplotlib import cm as cm
import matplotlib.colors as colors
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
import matplotlib.image as mpimg
from numpy import * 
import pylab 

import sqlite3 as lite
import sys

import matplotlib.dates as mdates  
from datetime import datetime, date, time
from matplotlib.legend_handler import HandlerLine2D


Tsfc_Facets = []
TCAN_ITEM=16
TA_ITEM=17  
with openFile('Tsfc_Facets.out') as f:
  count = 0
  for line in f:
    if (count == 0):
      count = count + 1
      continue
    line = line.split() # to deal with blank
    if line:            # lines (ie skip them)
      line = [float(i) for i in line]
      Tsfc_Facets.append(line) 
    count = count + 1
    		
    		
def isBlank(value):
	  if value == '':
	    value = pylab.nan
	  return value
    		
def annotateGraph(time):
  try:
    con = None
    con = lite.connect('/home/kerryn/Documents/Work/Data/CityOfMelbourne2011-12/CoM-2011-2.db')
    cur = con.cursor()  
    #print sql
    cur.execute(sql)
    rows = cur.fetchall()
    #print rows[0][0],rows[0][1],rows[0][2], rows[0][3],rows[0][4],rows[0][5], rows[0][6],rows[0][7],rows[0][8]
    return rows  
  except lite.Error, e:
    print "Error %s:" % e.args[0]
    sys.exit(1)    
  finally:    
    if con:
        con.close()
 
 
#define a pulse
def pulse(x, mid, width_top, width_bottom):
    if abs(mid-x)<.5*width_top: 
        return 1.0; 
    elif abs(mid-x)<.5*width_bottom:
        if (x>mid): 
            return 1.-2*(x-(mid+.5*width_top))/(width_bottom-width_top);
        else: 
            return 1.-2*((mid-.5*width_top)-x)/(width_bottom-width_top);
    else: 
        return 0.;
		  
#generate pulse train
#t = arange(0,1,.005) 
t = linspace(0,1,9) 
pr = array([pulse(i,.75,.245,.75) for i in t])
pg = array([pulse(i,.5,.245,.75) for i in t]) 
pb = array([pulse(i,.25,.245,.75) for i in t]) 
newcolors = [(pr[i],pg[i],pb[i]) for i in range(len(pr))] 
		
import subprocess

def min(list):
  min = list[0]
  for elm in list[1:]:
    if elm < min:
      min = elm
  #print "The minimum value in the list is: " + str(min)
  return min[0]
		  
def max(list):
  max = list[0]
  for elm in list[1:]:
    if elm > max:
      max = elm
  #print "The maximum value in the list is: " + str(max)
  return max[0]
		  
with openFile('lp31_bhbl150_vertices_toMatlab.out') as f:
    P = []
    for line in f:
        line = line.split() # to deal with blank
        if line:            # lines (ie skip them)
            line = [float(i) for i in line]
            P.append(line)

with openFile('lp31_bhbl150_faces_toMatlab.out') as f:
    F = []
    for line in f:
        line = line.split() # to deal with blank
        if line:            # lines (ie skip them)
            line = [float(i) for i in line]
            F.append(line)

def getColors(m,a):
    b=m.to_rgba(a)
    #print a
    return [(i[0],i[1],i[2]) for i in b]
    		
    		
def getFaceMidpointsZ(pc):
    a=[]
    		
    for i in pc:
        v=0
        for j in i:
            v=v+j[2]
        v=v/4.
        a.append(v)
    return a
    		
def getColorList(z,minValue,maxValue,cmap):
    zlen=len(z)
    valueRange = maxValue - minValue
    colorArray = [[]] * zlen
    for count in range(0,zlen):
      colorValue = (z[count][0] - minValue) / valueRange
      #print colorValue
      temp = cmap(colorValue)
      colorArray[count]=temp
    return colorArray
    		
## get first face values 1,2,3,4 map to vertices 1,2,3,4
## color value is face[i]
fListLength = len(F)
		
#fListLength = 5
		
pc = [[]] * fListLength
colorArray = [[]] * fListLength
for count in range(0,fListLength):
  temp=P[-1+int(F[count][0])],P[-1+int(F[count][1])],P[-1+int(F[count][2])],P[-1+int(F[count][3])]
  pc[count]=temp
		  
#Create a color map that goes from blue to white to red
cdict = {'red':   ((0,    0, 0),  #i.e. at value 0, red component is 0. First parameter is the value, second is the color component. Ignore the third parameter, it is for discontinuities.
                   (0.5,  1, 1),  #     at value 0.5, red component is 1.
                   (1,    1, 1)), #     at value 1, red component is 1
         'green': ((0,    0, 0),
                   (0.5,  1, 1),
                   (1,    0, 0)),
         'blue':  ((0,    1, 1),
                   (0.5,  1, 1),
                   (1,    0, 0))}

def findNearestNeighbors(x,y,z):
  neighbors = []
  face1=findFace(x,y-1,z)
  face2=findFace(x,y+1,z)
  face3=findFace(x-1,y,z)
  face4=findFace(x+1,y,z)
		  
  face0 = findFace(x, y, z)
  if (face0 >= 0):
    neighbors.append(face0)
  
  if (face1 >= 0):
    neighbors.append(face1)
  if (face2 >= 0):
    neighbors.append(face2)
  if (face3 >= 0):
    neighbors.append(face3)
  if (face4 >= 0):
    neighbors.append(face4)
    
  return neighbors
		  
def getNeighborsAverage(neighbors,values):
  lenNeighbors = len(neighbors)
  total = 0		     
  for count in range(0,lenNeighbors):
    total = total + values[ neighbors[count] ][0]
  return total / lenNeighbors
		  

def findFace(x, y, z):
  faceToFind = -9999
  corners = []
  corner1=0
  corner2=0
  corner3=0
  corner4=0
  pListLength = len(P)
  z1 = z + 0.5
  x1 = x - 0.5
  x2 = x + 0.5
  y1 = y - 0.5
  y2 = y + 0.5
		  
  for count in range(0,pListLength):
	  
    #match x1,y1,z1
    if (P[count][0] == x1 and P[count][1] == y1 and P[count][2] == z1 ):
      corner1=count+1
    if (P[count][0] == x1 and P[count][1] == y2 and P[count][2] == z1 ):
      corner2=count+1
    if (P[count][0] == x2 and P[count][1] == y1 and P[count][2] == z1 ):
      corner3=count+1
    if (P[count][0] == x2 and P[count][1] == y2 and P[count][2] == z1 ):
      corner4=count+1
    		  
  #print corner1, corner2, corner3, corner4
  corners.append(corner1)
  corners.append(corner2)
  corners.append(corner3)
  corners.append(corner4)
  cornersSort = sorted(corners)
		  
  fListLength = len(F)
  for count in range(0,fListLength):
    if ( sorted( F[count] ) == cornersSort ):
      faceToFind=count
    		  
  return faceToFind	
		  
def drawGraph(tim,label):
  from datetime import datetime, date, time
  
  # label='2012-01-31-0300'
  year = label[0 : 4]
  month = label[5 : 5 + 2]
  day = label[8 : 8 + 2]
  hour = label[11 : 11 + 2]
  minute = label[13 : 13 + 2]
		  
  d = date(int(year), int(month), int(day))
  t = time(int(hour), int(minute))
  dateTimeofData = datetime.combine(d, t)
		  
  try:
    f = openFile('toMatlab_utci_yd040_lp31_bhbl150_lat38S_stror00_tim' + tim + '.out')
  except IOError:
    return
  except KeyError:
    return
		  
  with openFile('toMatlab_utci_yd040_lp31_bhbl150_lat38S_stror00_tim' + tim + '.out') as f:
    utci = []
    for line in f:
        line = line.split() # to deal with blank
        if line:            # lines (ie skip them)
            line = [float(i) for i in line]
            utci.append(line)
  
		  
  with openFile('toMatlab_tmrt_yd040_lp31_bhbl150_lat38S_stror00_tim' + tim + '.out') as f:
    tmrt = []
    for line in f:
        line = line.split() # to deal with blank
        if line:            # lines (ie skip them)
            line = [float(i) for i in line]
            tmrt.append(line)
  
  with openFile('toMatlab_Tsfc_yd040_lp31_bhbl150_lat38S_stror00_tim' + tim + '.out') as f:
    tsfc = []
    for line in f:
        line = line.split() # to deal with blank
        if line:            # lines (ie skip them)
            line = [float(i) for i in line]
            tsfc.append(line)              
  #z=tsfc
  tsfcListLength = len(utci)
  rowNumber = int(tim)/100
  degree=u'\N{DEGREE SIGN}''C'
		  
  year = label[0 : 4]
  month = label[5 : 5 + 2]
  day = label[8 : 8 + 2]
  time = label[11 : 11 + 4]
  timecode=year + '' + month + '' + day + '' + time
		  
		
daysAndTimesTotal=[]  
		
daysAndTimes=[]  
		

def drawAggGraphs():
  #import datetime as datetime
  dayCount = 0
  #print daysAndTimesTotal
  length = len(daysAndTimesTotal)
  	  
  #d = date(int(2000), int(1), int(1))
  #t = time(int(1), int(00))
  #dateTimeData = datetime.combine(d, t)
  	  
  #datesToPlot= [dateTimeData] * 24
  datesToPlot = []
  day = 1
  for count in range(0,24):
    #print count
    if (count == 24):
      hour = 0
      day = day + 1
    else:
      hour = count
    d = date(int(2000), int(1), int(day))
    t = time(int(hour), int(00))
    dateTimeData = datetime.combine(d, t)
    #datesToPlot[count] = dateTimeData
    datesToPlot.append(dateTimeData)
    
  
  for count in range(0,length):   
    hour = daysAndTimesTotal[count].hour
    if (hour == 0):
      dayCount = dayCount + 1
    #print hour
    		
  #print tmrtEM5TotalAgg
  #print tmrtEM11TotalAgg
  #print tmrtEM8TotalAgg
  #print petEM5TotalAgg
  #print petEM11TotalAgg
  #print petEM8TotalAgg
  #print surftempEM5TotalAgg
  #print utcitempEM5TotalAgg
  #print surftempEM11TotalAgg
  #print utcitempEM11TotalAgg
  #print surftempEM8TotalAgg
  #print utcitempEM8TotalAgg
  #print surftempEM5NTotalAgg
  #print utcitempEM5NTotalAgg
  #print surftempEM11NTotalAgg
  #print utcitempEM11NTotalAgg
  #print surftempEM8NTotalAgg
  #print utcitempEM8NTotalAgg
  #print surftempTmrtEM5NTotalAgg
  #print surftempTmrtEM11NTotalAgg
  #print surftempTmrtEM8NTotalAgg
  
  fig = plt.figure()
  fig.set_dpi(100)
  fig.set_size_inches(15.36, 9.00)
  
  	  
  plt.title("PrestonBaseSmall 30 day average - observations vs. VTUF - " + label)
  plt.ylabel("temp C")
  plt.grid(True)
  plt.legend(fontsize=8,bbox_to_anchor=(0.12, 1),handler_map={utcitempPlotEM5N: HandlerLine2D(numpoints=2)})
  #plt.show()
  plt.savefig('30DayComparison' + '_' + label + '.png')
  plt.close()
 

  tmrtObsTotalAggAve= [0.0] * 24
  utciObsTotalAggAve= [0.0] * 24
  utcitempVtufTotalAggAve= [0.0] * 24
  tmrtVtufTotalAggAve= [0.0] * 24
  for count in range(0,24):
	    		
	fig = plt.figure()
	fig.set_dpi(100)
	fig.set_size_inches(15.36, 9.00)
                                 
	utcitempPlotEM5NAve, = plt.plot_date(x=datesToPlot, y=utcitempVtufTotalAggAve, fmt="bo-", label='UTCI ave VTUF', ls="dotted", linewidth=2)
	pettempPlotEM5Ave, = plt.plot_date(x=datesToPlot, y=utciObsTotalAggAve, fmt="bx-", label='UTCI ave Obs')
	surftempTmrtPlotEM5NAve, = plt.plot_date(x=datesToPlot, y=tmrtVtufTotalAggAve, fmt="ro-", label='Tmrt ave VTUF', ls="dotted", linewidth=2)
	tmrttempPlotEM5Ave, = plt.plot_date(x=datesToPlot, y=tmrtObsTotalAggAve, fmt="rx-", label='Tmrt ave Obs')
			  
	plt.title("PrestonBaseSmall 30 day average - ave observations vs. ave VTUF - " + label)
	plt.ylabel("temp C")
	plt.grid(True)
	plt.legend(fontsize=8,bbox_to_anchor=(0.12, 1),handler_map={utcitempPlotEM5NAve: HandlerLine2D(numpoints=2)})
	plt.savefig('30DayComparisonAve' + '_' + label + '.png')
	plt.close()  		

tim='0000'
label='2004-02-09-0000'
drawGraph(tim,label)
tim='0100'
label='2004-02-09-0100'
drawGraph(tim,label)
tim='0200'
label='2004-02-09-0200'
drawGraph(tim,label)
tim='0300'
label='2004-02-09-0300'
drawGraph(tim,label)
tim='0400'
label='2004-02-09-0400'
drawGraph(tim,label)
tim='0500'
label='2004-02-09-0500'
drawGraph(tim,label)
tim='0600'
label='2004-02-09-0600'
drawGraph(tim,label)
tim='0700'
label='2004-02-09-0700'
drawGraph(tim,label)
tim='0800'
label='2004-02-09-0800'
drawGraph(tim,label)
tim='0900'
label='2004-02-09-0900'
drawGraph(tim,label)
tim='1000'
label='2004-02-09-1000'
drawGraph(tim,label)
tim='1100'
label='2004-02-09-1100'
drawGraph(tim,label)
tim='1200'
label='2004-02-09-1200'
drawGraph(tim,label)
tim='1300'
label='2004-02-09-1300'
drawGraph(tim,label)
tim='1400'
label='2004-02-09-1400'
drawGraph(tim,label)
tim='1500'
label='2004-02-09-1500'
drawGraph(tim,label)
tim='1600'
label='2004-02-09-1600'
drawGraph(tim,label)
tim='1700'
label='2004-02-09-1700'
drawGraph(tim,label)
tim='1800'
label='2004-02-09-1800'
drawGraph(tim,label)
tim='1900'
label='2004-02-09-1900'
drawGraph(tim,label)
tim='2000'
label='2004-02-09-2000'
drawGraph(tim,label)
tim='2100'
label='2004-02-09-2100'
drawGraph(tim,label)
tim='2200'
label='2004-02-09-2200'
drawGraph(tim,label)
tim='2300'
label='2004-02-09-2300'
drawGraph(tim,label)

#print surftemp
#print utcitemp
#print daysAndTimes
fig = plt.figure()
fig.set_dpi(100)
fig.set_size_inches(15.36, 9.00)


plt.title("PrestonBaseSmall observations vs. VTUF - " + label)
plt.ylabel("temp C")
plt.grid(True)
#plt.show()
plt.savefig('Comparison' + tim + '_' + label + '.png')
plt.close()



daysAndTimes=[]


drawAggGraphs()

