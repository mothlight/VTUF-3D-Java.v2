python MatlabPatchesPlot3.py

