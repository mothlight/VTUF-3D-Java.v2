import zipfile
import os.path
def openFile(filename):
  if (  os.path.isfile("out.zip") ):
     z = zipfile.ZipFile("out.zip", "r")
     f = z.open(filename)     
  else:
    f = open(filename)  
  return f


from matplotlib import pyplot as plt
from matplotlib import cm as cm
import matplotlib.colors as colors
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
import matplotlib.image as mpimg
from numpy import * 
import pylab 

import sqlite3 as lite
import sys

import matplotlib.dates as mdates  
from datetime import datetime, date, time
from matplotlib.legend_handler import HandlerLine2D

import numpy as np  	
import subprocess


with openFile('lp31_bhbl150_vertices_toMatlab.out') as f:
    P = []
    for line in f:
        line = line.split() # to deal with blank
        if line:            # lines (ie skip them)
            line = [float(i) for i in line]
            P.append(line)

with openFile('lp31_bhbl150_faces_toMatlab.out') as f:
    F = []
    for line in f:
        line = line.split() # to deal with blank
        if line:            # lines (ie skip them)
            line = [float(i) for i in line]
            F.append(line)

def findNearestNeighbors(x,y,z):
  neighbors = []
  face1=findFace(x,y-1,z)
  face2=findFace(x,y+1,z)
  face3=findFace(x-1,y,z)
  face4=findFace(x+1,y,z)

  face0 = findFace(x, y, z)
  if (face0 >= 0):
    neighbors.append(face0)
  
  if (face1 >= 0):
    neighbors.append(face1)
  if (face2 >= 0):
    neighbors.append(face2)
  if (face3 >= 0):
    neighbors.append(face3)
  if (face4 >= 0):
    neighbors.append(face4)
    
  return neighbors
		  
def getNeighborsAverage(neighbors,values):
  lenNeighbors = len(neighbors)
  total = 0		     
  for count in range(0,lenNeighbors):
    total = total + values[ neighbors[count] ][0]
  return total / lenNeighbors
		  
def findFace(x, y, z):
  faceToFind = -9999
  corners = []
  corner1=0
  corner2=0
  corner3=0
  corner4=0
  pListLength = len(P)
  z1 = z + 0.5
  x1 = x - 0.5
  x2 = x + 0.5
  y1 = y - 0.5
  y2 = y + 0.5
		  
  for count in range(0,pListLength):
    #match x1,y1,z1
    if (P[count][0] == x1 and P[count][1] == y1 and P[count][2] == z1 ):
      corner1=count+1
    if (P[count][0] == x1 and P[count][1] == y2 and P[count][2] == z1 ):
      corner2=count+1
    if (P[count][0] == x2 and P[count][1] == y1 and P[count][2] == z1 ):
      corner3=count+1
    if (P[count][0] == x2 and P[count][1] == y2 and P[count][2] == z1 ):
      corner4=count+1
    		  
  #print corner1, corner2, corner3, corner4
  corners.append(corner1)
  corners.append(corner2)
  corners.append(corner3)
  corners.append(corner4)
  cornersSort = sorted(corners)
		  
  fListLength = len(F)
  for count in range(0,fListLength):
    if ( sorted( F[count] ) == cornersSort ):
      faceToFind=count
    		  
  return faceToFind	
		  
def drawGraph(tim,label,x,y,zIn,size):
  from datetime import datetime, date, time
  
  # label='2012-01-31-0300'
  #year = label[0 : 4]
  #month = label[5 : 5 + 2]
  #day = label[8 : 8 + 2]
  #hour = label[11 : 11 + 2]
  #minute = label[13 : 13 + 2]
		  
  #d = date(int(year), int(month), int(day))
  #t = time(int(hour), int(minute))
  #dateTimeofData = datetime.combine(d, t)
		  
  try:
    f = openFile('toMatlab_utci_yd040_lp31_bhbl150_lat38S_stror00_tim' + tim + '.out')
  except IOError:
    return
			
  with openFile('toMatlab_utci_yd040_lp31_bhbl150_lat38S_stror00_tim' + tim + '.out') as f:
    utci = []
    for line in f:
        line = line.split() # to deal with blank
        if line:            # lines (ie skip them)
            line = [float(i) for i in line]
            utci.append(line)
  
		  
  with openFile('toMatlab_tmrt_yd040_lp31_bhbl150_lat38S_stror00_tim' + tim + '.out') as f:
    tmrt = []
    for line in f:
        line = line.split() # to deal with blank
        if line:            # lines (ie skip them)
            line = [float(i) for i in line]
            tmrt.append(line)
  
  with openFile('toMatlab_Tsfc_yd040_lp31_bhbl150_lat38S_stror00_tim' + tim + '.out') as f:
    tsfc = []
    for line in f:
        line = line.split() # to deal with blank
        if line:            # lines (ie skip them)
            line = [float(i) for i in line]
            tsfc.append(line)  
  
  tsfcListLength = len(utci)
  rowNumber = int(tim)/100
  degree=u'\N{DEGREE SIGN}''C'
		  
  #year = label[0 : 4]
  #month = label[5 : 5 + 2]
  #day = label[8 : 8 + 2]
  #time = label[11 : 11 + 4]
  #timecode=year + '' + month + '' + day + '' + time
		  
  zUTCI=zIn.copy()
  zTMRT=zIn.copy()
  zTSFC=zIn.copy()
		  
  count = 0
  for xcount in range(0,size):
    for ycount in range(0,size):   
    	
      newY=ycount
      newX=xcount
    		  
      utciValue = np.nan
      tmrtValue = np.nan
      tsfcValue = np.nan
    		  
      face = zUTCI[newX][newY]
    		  
      if (face == -9999):
	utciValue = np.nan
	tmrtValue = np.nan
	tsfcValue = np.nan
      elif (math.isnan(face)):
	utciValue = np.nan
	tmrtValue = np.nan
	tsfcValue = np.nan
      else:
	utciValue = utci[int(face)][0]
	tmrtValue = tmrt[int(face)][0]
	tsfcValue = tsfc[int(face)][0]
			
      np.put(zUTCI, [count], [utciValue])
      np.put(zTMRT, [count], [tmrtValue])
      np.put(zTSFC, [count], [tsfcValue])
      count = count + 1
    		  
    		  
  fig = plt.figure()
  fig.set_dpi(100)
  fig.set_size_inches(15.36, 9.00)
  np.save(tim + '_' + 'zUTCI', zUTCI)
  cs=plt.imshow(zUTCI, interpolation='none',cmap = cm.jet)
  cbar = fig.colorbar(cs)
  cbar.set_label('UTCI ($^\circ$C)',size=12)
  
  fig.suptitle('PrestonBaseSmall - UTCI ' + label, fontsize=14, fontweight='bold')
  plt.xlabel('x (5.0m grid)')
  plt.ylabel('y')
  plt.grid(True)
  #plt.show()
  plt.savefig('UTCI-0MSlice-' + tim + '_' + label + '.png')
  plt.close()
  
  fig = plt.figure()
  fig.set_dpi(100)
  fig.set_size_inches(15.36, 9.00)
  cs=plt.imshow(zTMRT, interpolation='none',cmap = cm.jet)
  cbar = fig.colorbar(cs)
  cbar.set_label('temp C',size=12)
  
  fig.suptitle('PrestonBaseSmall - Tmrt ' + label, fontsize=14, fontweight='bold')
  plt.xlabel('x (5.0m grid)')
  plt.ylabel('y')
  plt.grid(True)
  #plt.show()
  plt.savefig('TMRT-0MSlice-' + tim + '_' + label + '.png')
  plt.close()
  
  fig = plt.figure()
  fig.set_dpi(100)
  fig.set_size_inches(15.36, 9.00)
  cs=plt.imshow(zTSFC, interpolation='none',cmap = cm.jet)
  cbar = fig.colorbar(cs)
  cbar.set_label('temp C',size=12)
  
  fig.suptitle('PrestonBaseSmall - Tsfc at ' + label, fontsize=14, fontweight='bold')
  plt.xlabel('x (5.0m grid)')
  plt.ylabel('y')
  plt.grid(True)
  #plt.show()
  plt.savefig('TSFC-0MSlice-' + tim + '_' + label + '.png')
  plt.close()  

  
size=4

x= np.arange(0,size)
y= np.arange(0,size)

X,Y = np.meshgrid(x,y)


v = -9999.
rows = size
cols = size
z = np.tile(v, (rows,cols))

count = 0
for ycount in range(0,size):
  for xcount in range(0,size):   
    #newY = size-ycount-1
    newY=ycount
    		
    face= findFace(xcount,newY,0)
    #if (face == -9999):
    #  face = np.nan
    #print xcount,ycount,face
    np.put(z, [count], [face])
    count = count + 1
    		
#print z

tim='0000'
label='2004-02-09-0000'
drawGraph(tim,label,x,y,z,size)
tim='0100'
label='2004-02-09-0100'
drawGraph(tim,label,x,y,z,size)
tim='0200'
label='2004-02-09-0200'
drawGraph(tim,label,x,y,z,size)
tim='0300'
label='2004-02-09-0300'
drawGraph(tim,label,x,y,z,size)
tim='0400'
label='2004-02-09-0400'
drawGraph(tim,label,x,y,z,size)
tim='0500'
label='2004-02-09-0500'
drawGraph(tim,label,x,y,z,size)
tim='0600'
label='2004-02-09-0600'
drawGraph(tim,label,x,y,z,size)
tim='0700'
label='2004-02-09-0700'
drawGraph(tim,label,x,y,z,size)
tim='0800'
label='2004-02-09-0800'
drawGraph(tim,label,x,y,z,size)
tim='0900'
label='2004-02-09-0900'
drawGraph(tim,label,x,y,z,size)
tim='1000'
label='2004-02-09-1000'
drawGraph(tim,label,x,y,z,size)
tim='1100'
label='2004-02-09-1100'
drawGraph(tim,label,x,y,z,size)
tim='1200'
label='2004-02-09-1200'
drawGraph(tim,label,x,y,z,size)
tim='1300'
label='2004-02-09-1300'
drawGraph(tim,label,x,y,z,size)
tim='1400'
label='2004-02-09-1400'
drawGraph(tim,label,x,y,z,size)
tim='1500'
label='2004-02-09-1500'
drawGraph(tim,label,x,y,z,size)
tim='1600'
label='2004-02-09-1600'
drawGraph(tim,label,x,y,z,size)
tim='1700'
label='2004-02-09-1700'
drawGraph(tim,label,x,y,z,size)
tim='1800'
label='2004-02-09-1800'
drawGraph(tim,label,x,y,z,size)
tim='1900'
label='2004-02-09-1900'
drawGraph(tim,label,x,y,z,size)
tim='2000'
label='2004-02-09-2000'
drawGraph(tim,label,x,y,z,size)
tim='2100'
label='2004-02-09-2100'
drawGraph(tim,label,x,y,z,size)
tim='2200'
label='2004-02-09-2200'
drawGraph(tim,label,x,y,z,size)
tim='2300'
label='2004-02-09-2300'
drawGraph(tim,label,x,y,z,size)

