import zipfile
import os.path
def openFile(filename):
  if (  os.path.isfile("out.zip") ):
     z = zipfile.ZipFile("out.zip", "r")
     f = z.open(filename)     
  else:
    f = open(filename)  
  return f


from matplotlib import pyplot as plt
from matplotlib import cm as cm
import matplotlib.colors as colors
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
import matplotlib.image as mpimg
from numpy import * 
 
Tsfc_Facets = [] 
TCAN_ITEM=16 
TA_ITEM=17   
with openFile('Tsfc_Facets.out') as f: 
  count = 0 
  for line in f: 
    if (count == 0): 
      count = count + 1 
      continue 
    line = line.split() # to deal with blank  
    if line:            # lines (ie skip them) 
      line = [float(i) for i in line] 
      Tsfc_Facets.append(line)  
    count = count + 1 
 
#define a pulse 
def pulse(x, mid, width_top, width_bottom): 
    if abs(mid-x)<.5*width_top: 
        return 1.0; 
    elif abs(mid-x)<.5*width_bottom: 
        if (x>mid): 
            return 1.-2*(x-(mid+.5*width_top))/(width_bottom-width_top); 
        else: 
            return 1.-2*((mid-.5*width_top)-x)/(width_bottom-width_top); 
    else: 
        return 0.; 
 
#generate pulse train 
#t = arange(0,1,.005) 
t = linspace(0,1,9) 
pr = array([pulse(i,.75,.245,.75) for i in t]) 
pg = array([pulse(i,.5,.245,.75) for i in t]) 
pb = array([pulse(i,.25,.245,.75) for i in t]) 
newcolors = [(pr[i],pg[i],pb[i]) for i in range(len(pr))] 
 

def min(list):
  min = list[0]
  for elm in list[1:]:
    if elm < min:
      min = elm
  #print "The minimum value in the list is: " + str(min)
  return min[0]
          
def max(list):
  max = list[0]
  for elm in list[1:]:
    if elm > max:
      max = elm
  #print "The maximum value in the list is: " + str(max)
  return max[0]

with openFile('lp31_bhbl150_vertices_toMatlab.out') as f:
    P = []
    for line in f:
        line = line.split() # to deal with blank 
        if line:            # lines (ie skip them)
            line = [float(i) for i in line]
            P.append(line)

with openFile('lp31_bhbl150_faces_toMatlab.out') as f:
    F = []
    for line in f:
        line = line.split() # to deal with blank 
        if line:            # lines (ie skip them)
            line = [float(i) for i in line]
            F.append(line)

def getColors(m,a):
    b=m.to_rgba(a)    
    #print a
    return [(i[0],i[1],i[2]) for i in b]
    
    
def getFaceMidpointsZ(pc):
    a=[]

    for i in pc:
        v=0
        for j in i:
            v=v+j[2]
        v=v/4.
        a.append(v)
    return a
    
def getColorList(z,minValue,maxValue,cmap):
    zlen=len(z)
    valueRange = maxValue - minValue    
    colorArray = [[]] * zlen
    for count in range(0,zlen):  
      colorValue = (z[count][0] - minValue) / valueRange
      #print colorValue
      temp = cmap(colorValue)
      colorArray[count]=temp
    return colorArray

## get first face values 1,2,3,4 map to vertices 1,2,3,4
## color value is face[i] 
fListLength = len(F)

#fListLength = 5

pc = [[]] * fListLength
colorArray = [[]] * fListLength
for count in range(0,fListLength):  
  temp=P[-1+int(F[count][0])],P[-1+int(F[count][1])],P[-1+int(F[count][2])],P[-1+int(F[count][3])]
  pc[count]=temp

#Create a color map that goes from blue to white to red
cdict = {'red':   ((0,    0, 0),  #i.e. at value 0, red component is 0. First parameter is the value, second is the color component. Ignore the third parameter, it is for discontinuities.
                   (0.5,  1, 1),  #     at value 0.5, red component is 1.
                   (1,    1, 1)), #     at value 1, red component is 1
         'green': ((0,    0, 0),
                   (0.5,  1, 1),
                   (1,    0, 0)),
         'blue':  ((0,    1, 1),
                   (0.5,  1, 1),
                   (1,    0, 0))}

def drawGraph(tim,label):
  fig = plt.figure()
  
  ax = plt.axes(projection='3d')
  #ax.set_xlim([9, 12])
  #ax.set_ylim([9, 12]) 
  ax.set_zlim([0.5, 2.0]) 
  ax.set_xlim([12.0,15.0])
  ax.set_ylim([12.0,15.0]) 

  #Make the color map and register it   
  #cmap1 = colors.LinearSegmentedColormap('UWR',cdict,256)
  cmap1 =colors.LinearSegmentedColormap.from_list('temp',newcolors)
  cm.register_cmap(name='UWR', cmap=cmap1)
  UWR = cm.get_cmap('UWR')

  collection = Poly3DCollection(pc, linewidths=1)
  ax.add_collection3d(collection)

  fz=getFaceMidpointsZ(pc)
  #print fz
  
  with openFile('toMatlab_utci_tim' + tim + '.out') as f:
    tsfc = []
    for line in f:
        line = line.split() # to deal with blank 
        if line:            # lines (ie skip them)
            line = [float(i) for i in line]
            tsfc.append(line)           
            
  z=tsfc
  tsfcListLength = len(tsfc)

  #Create a variable for the colorbar
  m = cm.ScalarMappable(cmap=UWR)
  m.set_array(z)

  #minValue = min(z) #- 0.25
  #maxValue = max(z) #+ 0.25
  minValue = 5
  maxValue = 50
  m.set_clim(vmin=minValue,vmax=maxValue)

  colorList = getColorList(z,minValue,maxValue,UWR)

  fig.suptitle('PrestonBaseSmall - UTCI at ' + label, fontsize=14, fontweight='bold')
  rowNumber = int(tim)/100
  degree=u'\N{DEGREE SIGN}''C'
  ax.text2D(0.00, -0.05, 'Tcan=' + str(Tsfc_Facets[rowNumber][TCAN_ITEM])  + degree + ', Ta=' + str(Tsfc_Facets[rowNumber][TA_ITEM])  + degree, transform=ax.transAxes, fontsize=10)
  ax.text2D(1.05, -0.05, "UTCI ($^\circ$C)", transform=ax.transAxes)
  ax.text2D(0.5, -0.05, "x (5.0m grid)", transform=ax.transAxes)
  ax.text2D(-0.05, 0.5, "y", transform=ax.transAxes)

  fig.colorbar(m)
  ax.set_xlabel('x')
  ax.set_ylabel('y')
  ax.set_zlabel('z')
  plt.gca().invert_yaxis()
  ax.view_init(elev=90., azim=-90.)
  collection.set_facecolor(colorList)
  #plt.show()

  plt.savefig('UTCI' + tim + '_' + label + '.png')
  plt.close()

tim='0000'
label='2004-02-09-0000'
drawGraph(tim,label)
tim='0100'
label='2004-02-09-0100'
drawGraph(tim,label)
tim='0200'
label='2004-02-09-0200'
drawGraph(tim,label)
tim='0300'
label='2004-02-09-0300'
drawGraph(tim,label)
tim='0400'
label='2004-02-09-0400'
drawGraph(tim,label)
tim='0500'
label='2004-02-09-0500'
drawGraph(tim,label)
tim='0600'
label='2004-02-09-0600'
drawGraph(tim,label)
tim='0700'
label='2004-02-09-0700'
drawGraph(tim,label)
tim='0800'
label='2004-02-09-0800'
drawGraph(tim,label)
tim='0900'
label='2004-02-09-0900'
drawGraph(tim,label)
tim='1000'
label='2004-02-09-1000'
drawGraph(tim,label)
tim='1100'
label='2004-02-09-1100'
drawGraph(tim,label)
tim='1200'
label='2004-02-09-1200'
drawGraph(tim,label)
tim='1300'
label='2004-02-09-1300'
drawGraph(tim,label)
tim='1400'
label='2004-02-09-1400'
drawGraph(tim,label)
tim='1500'
label='2004-02-09-1500'
drawGraph(tim,label)
tim='1600'
label='2004-02-09-1600'
drawGraph(tim,label)
tim='1700'
label='2004-02-09-1700'
drawGraph(tim,label)
tim='1800'
label='2004-02-09-1800'
drawGraph(tim,label)
tim='1900'
label='2004-02-09-1900'
drawGraph(tim,label)
tim='2000'
label='2004-02-09-2000'
drawGraph(tim,label)
tim='2100'
label='2004-02-09-2100'
drawGraph(tim,label)
tim='2200'
label='2004-02-09-2200'
drawGraph(tim,label)
tim='2300'
label='2004-02-09-2300'
drawGraph(tim,label)

