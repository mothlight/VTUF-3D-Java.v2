import UTCI
from math import log10, floor ,exp

def round_sigfigs(num, sig_figs):
    """Round to specified number of sigfigs.
    """
    if num != 0:
        return round(num, -int(floor(log10(abs(num))) - (sig_figs - 1)))
    else:
        return 0  # Can't take the log of 0
        		

import zipfile
import os.path
def openFile(filename):
  if (  os.path.isfile("out.zip") ):
     z = zipfile.ZipFile("out.zip", "r")
     f = z.open(filename)  
  else:
    f = open(filename)  
  return f
	
##  Thorsson 2007
#  mean radiant flux density (Sstr)
#  Sstr = Ak SUM Ki Fi + Ep SUM Li Fi
# Ki short wave fluxes
# Li long wave fluxes
# Fi  angular factors
# Ak absorption coefficient for shortwave (standard value 0.7)
# Ep emissivity for human body (Ep is equal to absorption coefficient for long wave) (Standrd value 0.97)

		
def round_sig(x, sig=2):
  if (x<0):
    return -round(x, sig-int(floor(log10(-x)))-1)
  else:
    return round(x, sig-int(floor(log10(x)))-1)

with open('forcing.dat') as f:
    forcingDat = f.readlines()

forcingDat1stline = forcingDat[0].split()
lengthForcingDat = int(forcingDat1stline[0])
halflengthForcingDat = int(lengthForcingDat/2)

for i in range(0, halflengthForcingDat):
    splitForcing = forcingDat[i*2+1].split()
    time=str(i )
    if ( len(time) < 2):
        time = '0' + time
        		
    kabsFile = 'toMatlab_Kabs_yd040_lp31_bhbl150_lat38S_stror00_tim' +time + '00.out'
    labsFile = 'toMatlab_Labs_yd040_lp31_bhbl150_lat38S_stror00_tim' + time+ '00.out'
    kreflFile ='toMatlab_Krefl_yd040_lp31_bhbl150_lat38S_stror00_tim' +time+ '00.out'
    lreflFile ='toMatlab_Lrefl_yd040_lp31_bhbl150_lat38S_stror00_tim' + time+ '00.out'
    tsfcFile ='toMatlab_Tsfc_yd040_lp31_bhbl150_lat38S_stror00_tim' + time+ '00.out'
    		
    utciFile = 'toMatlab_utci_tim' +time + '00.out'
    tmrtFile = 'toMatlab_tmrt_tim' +time + '00.out'
    		
    outFile = open(utciFile,'w')
    outFile2 = open(tmrtFile,'w')
    
    with openFile(tsfcFile) as f:
        tsfcDat = f.readlines()
    
    with openFile(kabsFile) as f:
        kabsDat = f.readlines()
    
    with openFile(labsFile) as f:
        labsDat = f.readlines()
    
    with openFile(kreflFile) as f:
        kreflDat = f.readlines()
    
    with openFile(lreflFile) as f:
        lreflDat = f.readlines()
    
    lengthDat = len(tsfcDat)
    for j in range(0, lengthDat):
    	
        Ta = float(splitForcing[2])
        TaK = Ta+273.15
        ws = float(splitForcing[4])
        vapor = float(splitForcing[3])
        RH=UTCI.calcRH(Ta, vapor)
        		
        kd=float(kabsDat[j])
        ld=float(labsDat[j])
        ku=float(kreflDat[j])
        lu=float(lreflDat[j])
        w=46.5 * vapor / TaK
        eClear = 1-(1+w) * exp( -1*(1.2+3.0 * w)**0.5  )
        ldnNew = eClear * 5.67E-08 * TaK**4
        #scheme from Offerle2003
        
        groundEmis=0.97
        Tsfc = float(tsfcDat[j])
        TsfcK = Tsfc+273.15
        lupNew = groundEmis * 5.67E-08 * TsfcK**4 + (1-groundEmis) * ldnNew
        
        solar = kd
        #Tmrt = UTCI.calcTmrtNew(Ta, ws, solar, RH, zenith)
        
        		
        
        
        Tmrt = UTCI.calcTmrt(kd, ld, ku, lu)
        #Tmrt = float(tsfcDat[j])
        Tmrt = round_sigfigs(Tmrt,4)
        utci=round_sigfigs(UTCI.fUTCI2(Ta, ws, RH, Tmrt), 4)
        outFile.write('   ' + str(utci) +  '\n')  
        outFile2.write('   ' + str(Tmrt) +  '\n')  
    outFile.close() 
    outFile2.close() 
    

