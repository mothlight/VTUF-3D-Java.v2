cd /home/kerryn/git/2018-03-MasterITProject/VTUF3DTesting/vtuf-3d
make
cd /home/kerryn/git/2018-03-MasterITProject/VTUF3DTesting/PrestonBaseSmall
./TUF3Dradiation
